package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.PoemNoteEntity
import com.example.data.PoemRepository
import com.example.model.BackgroundStyle
import com.example.model.LiteraryFont
import com.example.model.MoodCategory
import com.example.model.TextAlignOption
import com.example.model.TextColorMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class StudioTemplatePreset(
    val id: String,
    val title: String,
    val subtitle: String,
    val sampleExcerpt: String,
    val mood: MoodCategory,
    val font: LiteraryFont,
    val background: BackgroundStyle,
    val align: TextAlignOption,
    val isItalic: Boolean = false,
    val overlayOpacity: Float = background.defaultOverlayOpacity,
)

val curatedStudioPresets = listOf(
    StudioTemplatePreset(
        id = "sajak_senja",
        title = "Sajak Senja Klasik",
        subtitle = "Playfair Display • Tengah • Latar Senja",
        sampleExcerpt = "Di ujung hari yang perlahan meredup,\nada rindu yang selalu belajar hidup.",
        mood = MoodCategory.RINDU,
        font = LiteraryFont.PLAYFAIR_DISPLAY,
        background = BackgroundStyle.IMG_SENJA,
        align = TextAlignOption.CENTER,
        isItalic = true,
    ),
    StudioTemplatePreset(
        id = "surat_mesin_tik",
        title = "Surat Mesin Tik",
        subtitle = "Courier Prime • Kiri • Kertas Vintage",
        sampleExcerpt = "Kepada waktu yang tak pernah menunggu,\naku titipkan sebait doa dalam kertas usang.",
        mood = MoodCategory.MELANKOLIS,
        font = LiteraryFont.COURIER_PRIME,
        background = BackgroundStyle.VINTAGE_AGED,
        align = TextAlignOption.LEFT,
    ),
    StudioTemplatePreset(
        id = "kaligrafi_romantis",
        title = "Surat Cinta Kaligrafi",
        subtitle = "Dancing Script • Tengah • Krem Klasik",
        sampleExcerpt = "Namamu tumbuh tenang di sela doa,\nseperti hujan pertama yang menyapa tanah.",
        mood = MoodCategory.ROMANTIS,
        font = LiteraryFont.DANCING_SCRIPT,
        background = BackgroundStyle.WARM_PAPER,
        align = TextAlignOption.CENTER,
    ),
    StudioTemplatePreset(
        id = "renungan_hujan",
        title = "Renungan di Balik Hujan",
        subtitle = "Lora • Kiri • Latar Hujan",
        sampleExcerpt = "Setiap rintik membawa ingatan yang tenang,\ntentang perjalanan dan hati yang lapang.",
        mood = MoodCategory.FILOSOFI,
        font = LiteraryFont.LORA,
        background = BackgroundStyle.IMG_HUJAN,
        align = TextAlignOption.LEFT,
    ),
    StudioTemplatePreset(
        id = "tinta_malam",
        title = "Monolog Tengah Malam",
        subtitle = "Merriweather • Kiri • Tinta Malam",
        sampleExcerpt = "Ketika kota terlelap dalam gelap,\npikiran paling jujur mulai berucap.",
        mood = MoodCategory.BEBAS,
        font = LiteraryFont.MERRIWEATHER,
        background = BackgroundStyle.MIDNIGHT_INK,
        align = TextAlignOption.LEFT,
    ),
    StudioTemplatePreset(
        id = "catatan_rimba",
        title = "Prosa Hutan Berkabut",
        subtitle = "Special Elite • Kiri • Hutan Berkabut",
        sampleExcerpt = "Di antara kabut pagi dan sunyi cemara,\naku menemukan kembali arti pulang.",
        mood = MoodCategory.FILOSOFI,
        font = LiteraryFont.SPECIAL_ELITE,
        background = BackgroundStyle.IMG_HUTAN,
        align = TextAlignOption.LEFT,
    ),
)

data class LibraryUiState(
    val allNotes: List<PoemNoteEntity> = emptyList(),
    val filteredNotes: List<PoemNoteEntity> = emptyList(),
    val pinnedNotes: List<PoemNoteEntity> = emptyList(),
    val searchQuery: String = "",
    val selectedMood: MoodCategory? = null,
    val onlyPinned: Boolean = false,
    val defaultPenName: String = "",
    val isDarkAppTheme: Boolean = false,
)

class LibraryViewModel(
    private val repository: PoemRepository,
) : ViewModel() {

    private val searchQuery = MutableStateFlow("")
    private val selectedMood = MutableStateFlow<MoodCategory?>(null)
    private val onlyPinned = MutableStateFlow(false)
    private val defaultPenName = MutableStateFlow(repository.getDefaultPenName())
    private val isDarkAppTheme = MutableStateFlow(repository.isDarkAppTheme())

    init {
        viewModelScope.launch {
            repository.seedStarterPoemsIfFirstLaunch()
        }
    }

    val uiState: StateFlow<LibraryUiState> = combine(
        repository.allNotes,
        searchQuery,
        selectedMood,
        onlyPinned,
        combine(defaultPenName, isDarkAppTheme) { pen, dark -> pen to dark },
    ) { notes, query, mood, pinnedOnly, (pen, dark) ->
        val normalizedQuery = query.trim().lowercase()
        val filtered = notes.filter { note ->
            val matchesMood = mood == null || note.mood == mood
            val matchesPinned = !pinnedOnly || note.isPinned
            val matchesQuery = normalizedQuery.isEmpty() ||
                note.title.lowercase().contains(normalizedQuery) ||
                note.content.lowercase().contains(normalizedQuery) ||
                note.penName.lowercase().contains(normalizedQuery)
            matchesMood && matchesPinned && matchesQuery
        }
        LibraryUiState(
            allNotes = notes,
            filteredNotes = filtered,
            pinnedNotes = notes.filter { it.isPinned },
            searchQuery = query,
            selectedMood = mood,
            onlyPinned = pinnedOnly,
            defaultPenName = pen,
            isDarkAppTheme = dark,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LibraryUiState(
            defaultPenName = repository.getDefaultPenName(),
            isDarkAppTheme = repository.isDarkAppTheme(),
        ),
    )

    fun onSearchQueryChange(query: String) {
        searchQuery.value = query
    }

    fun onSelectMood(mood: MoodCategory?) {
        selectedMood.value = mood
    }

    fun onTogglePinnedFilter() {
        onlyPinned.value = !onlyPinned.value
    }

    fun togglePin(note: PoemNoteEntity) {
        viewModelScope.launch {
            repository.togglePin(note.id, note.isPinned)
        }
    }

    fun deleteNote(noteId: Long) {
        viewModelScope.launch {
            repository.deleteNote(noteId)
        }
    }

    fun createNewNote(onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.createNote(
                PoemNoteEntity(
                    penName = repository.getDefaultPenName(),
                ),
            )
            onCreated(id)
        }
    }

    fun createNoteFromPreset(preset: StudioTemplatePreset, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.createNote(
                PoemNoteEntity(
                    penName = repository.getDefaultPenName(),
                    moodCategory = preset.mood.name,
                    fontName = preset.font.name,
                    backgroundStyle = preset.background.name,
                    textAlign = preset.align.name,
                    isItalic = preset.isItalic,
                    overlayOpacity = preset.overlayOpacity,
                    textColorMode = TextColorMode.AUTO.name,
                ),
            )
            onCreated(id)
        }
    }

    fun updateDefaultPenName(name: String) {
        repository.setDefaultPenName(name)
        defaultPenName.value = name.trim()
    }

    fun setDarkAppTheme(enabled: Boolean) {
        repository.setDarkAppTheme(enabled)
        isDarkAppTheme.value = enabled
    }
}

class LibraryViewModelFactory(
    private val repository: PoemRepository,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return LibraryViewModel(repository) as T
    }
}
