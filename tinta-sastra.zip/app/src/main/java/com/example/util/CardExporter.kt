package com.example.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.ColorUtils
import com.example.R
import com.example.data.PoemNoteEntity
import com.example.model.BackgroundStyle
import com.example.model.ExportRatio
import com.example.model.TextAlignOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream
import kotlin.random.Random

object CardExporter {

    suspend fun renderLiteraryCardBitmap(
        context: Context,
        note: PoemNoteEntity,
        ratio: ExportRatio,
        includeWatermark: Boolean = true,
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = ratio.widthPx
        val height = ratio.heightPx
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgStyle = note.bgStyle
        val baseColor = bgStyle.baseColorHex.toInt()
        canvas.drawColor(baseColor)

        // 1. Draw photo background or paper grain/vignette
        if (bgStyle.isPhoto) {
            val loaded = loadSampledBackgroundBitmap(
                context = context,
                style = bgStyle,
                customImagePath = note.customImagePath,
                maxDimensionPx = 1440,
            )
            if (loaded != null) {
                val cropped = centerCropBitmap(loaded, width, height)
                val blurRadius = note.backgroundBlur.toInt().coerceIn(0, 25)
                val processed = if (blurRadius > 0) {
                    val downscaled = Bitmap.createScaledBitmap(
                        cropped,
                        (width / 3).coerceAtLeast(180),
                        (height / 3).coerceAtLeast(180),
                        true,
                    )
                    val blurred = fastStackBlur(downscaled, (blurRadius * 0.9f).toInt().coerceAtLeast(1))
                    Bitmap.createScaledBitmap(blurred, width, height, true)
                } else {
                    cropped
                }
                canvas.drawBitmap(processed, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
            }
            val overlayAlpha = (note.overlayOpacity.coerceIn(0f, 0.85f) * 255).toInt()
            if (overlayAlpha > 0) {
                canvas.drawColor(Color.argb(overlayAlpha, 12, 10, 9))
            }
        } else {
            drawPaperTexture(canvas, width, height, bgStyle)
        }

        // 2. Resolve ink & accent colors
        val inkColor = note.colorMode.resolveHex(bgStyle).toInt()
        val subtleInkColor = ColorUtils.setAlphaComponent(inkColor, 165)
        val ruleColor = ColorUtils.setAlphaComponent(inkColor, 75)
        val frameColor = ColorUtils.setAlphaComponent(inkColor, 48)

        // Subtle inset literary border
        val borderInset = 44f
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = frameColor
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRect(borderInset, borderInset, width - borderInset, height - borderInset, framePaint)

        // 3. Load fonts
        val bodyTypeface = runCatching {
            ResourcesCompat.getFont(context, note.font.fontRes)
        }.getOrNull() ?: Typeface.SERIF

        val uiTypeface = runCatching {
            ResourcesCompat.getFont(context, R.font.plus_jakarta_sans)
        }.getOrNull() ?: Typeface.SANS_SERIF

        val horizontalPadding = 112
        val contentWidth = width - (horizontalPadding * 2)
        val maxBodyHeight = (height * 0.62f).toInt()

        val alignment = when (note.align) {
            TextAlignOption.LEFT, TextAlignOption.JUSTIFY -> Layout.Alignment.ALIGN_NORMAL
            TextAlignOption.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignOption.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
        }

        val cleanTitle = note.title.trim()
        val cleanBody = note.content.trim().ifEmpty { "…" }
        val cleanPen = note.penName.trim()
        val dateText = formatIndonesianFullDate(note.updatedAt)

        // Scale down typography gracefully if poem is long so nothing clips off-card
        var scaleFactor = (width / 420f)
        var titleLayout: StaticLayout? = null
        var bodyLayout: StaticLayout

        while (true) {
            val titleSizePx = (note.fontSizeSp + 6f) * scaleFactor
            val bodySizePx = note.fontSizeSp * scaleFactor

            titleLayout = if (cleanTitle.isNotEmpty()) {
                val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = inkColor
                    textSize = titleSizePx
                    typeface = bodyTypeface
                    isFakeBoldText = true
                    letterSpacing = 0.01f
                }
                buildStaticLayout(
                    text = cleanTitle,
                    paint = titlePaint,
                    width = contentWidth,
                    alignment = alignment,
                    lineSpacingMultiplier = 1.25f,
                    justify = false,
                )
            } else {
                null
            }

            val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = inkColor
                textSize = bodySizePx
                typeface = bodyTypeface
                isFakeBoldText = note.isBold
                textSkewX = if (note.isItalic) -0.22f else 0f
                isUnderlineText = note.isUnderline
                letterSpacing = note.letterSpacingEm
            }

            bodyLayout = buildStaticLayout(
                text = cleanBody,
                paint = bodyPaint,
                width = contentWidth,
                alignment = alignment,
                lineSpacingMultiplier = note.lineHeightMultiplier,
                justify = note.align == TextAlignOption.JUSTIFY,
            )

            val combinedHeight = (titleLayout?.height ?: 0) + bodyLayout.height + 90
            if (combinedHeight <= maxBodyHeight || scaleFactor <= 1.25f) {
                break
            }
            scaleFactor *= 0.88f
        }

        val metaSizePx = 13f * (width / 420f)
        val penPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = subtleInkColor
            textSize = metaSizePx
            typeface = bodyTypeface
            textSkewX = -0.15f
        }
        val metaLine = buildString {
            if (cleanPen.isNotEmpty()) {
                append("— ").append(cleanPen)
            }
            if (cleanPen.isNotEmpty() && dateText.isNotEmpty()) {
                append("  •  ")
            }
            append(dateText)
        }
        val metaLayout = buildStaticLayout(
            text = metaLine,
            paint = penPaint,
            width = contentWidth,
            alignment = alignment,
            lineSpacingMultiplier = 1.2f,
            justify = false,
        )

        val titleGap = if (titleLayout != null) 42 else 0
        val metaGap = 54
        val totalBlockHeight = (titleLayout?.height ?: 0) + titleGap + bodyLayout.height + metaGap + metaLayout.height

        var currentY = ((height - totalBlockHeight) / 2f).coerceAtLeast(110f)

        // Draw Title
        if (titleLayout != null) {
            canvas.save()
            canvas.translate(horizontalPadding.toFloat(), currentY)
            titleLayout.draw(canvas)
            canvas.restore()
            currentY += titleLayout.height

            // Subtle ornament divider line aligned with text alignment
            val lineWidth = 88f
            val lineX = when (note.align) {
                TextAlignOption.CENTER -> (width - lineWidth) / 2f
                TextAlignOption.RIGHT -> width - horizontalPadding - lineWidth
                else -> horizontalPadding.toFloat()
            }
            val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ruleColor
                strokeWidth = 2.5f
            }
            val ruleY = currentY + 20f
            canvas.drawLine(lineX, ruleY, lineX + lineWidth, ruleY, dividerPaint)
            currentY += titleGap
        }

        // Draw Body
        canvas.save()
        canvas.translate(horizontalPadding.toFloat(), currentY)
        bodyLayout.draw(canvas)
        canvas.restore()
        currentY += bodyLayout.height + metaGap

        // Draw Author & Date
        canvas.save()
        canvas.translate(horizontalPadding.toFloat(), currentY)
        metaLayout.draw(canvas)
        canvas.restore()

        // Optional subtle literary signature at bottom
        if (includeWatermark) {
            val wmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ColorUtils.setAlphaComponent(inkColor, 110)
                textSize = 22f
                typeface = uiTypeface
                letterSpacing = 0.22f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("TINTA SASTRA", width / 2f, height - 74f, wmPaint)
        }

        bitmap
    }

    private fun drawPaperTexture(
        canvas: Canvas,
        width: Int,
        height: Int,
        style: BackgroundStyle,
    ) {
        if (style == BackgroundStyle.CLEAN_WHITE) return

        val vignetteColor = when (style) {
            BackgroundStyle.WARM_PAPER -> Color.argb(24, 150, 118, 76)
            BackgroundStyle.VINTAGE_AGED -> Color.argb(48, 128, 86, 40)
            BackgroundStyle.MIDNIGHT_INK -> Color.argb(65, 4, 5, 8)
            else -> Color.TRANSPARENT
        }
        if (vignetteColor != Color.TRANSPARENT) {
            val radial = RadialGradient(
                width / 2f,
                height / 2f,
                maxOf(width, height) * 0.72f,
                Color.TRANSPARENT,
                vignetteColor,
                Shader.TileMode.CLAMP,
            )
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), Paint().apply { shader = radial })
        }

        // Subtle organic paper speckles
        val rng = Random(style.ordinal * 997 + 13)
        val dotColor = if (style == BackgroundStyle.MIDNIGHT_INK) {
            Color.argb(26, 245, 238, 226)
        } else {
            Color.argb(18, 92, 68, 44)
        }
        val dotPaint = Paint().apply { color = dotColor }
        repeat(650) {
            val x = rng.nextFloat() * width
            val y = rng.nextFloat() * height
            val r = 0.8f + rng.nextFloat() * 1.4f
            canvas.drawCircle(x, y, r, dotPaint)
        }
    }

    private fun buildStaticLayout(
        text: CharSequence,
        paint: TextPaint,
        width: Int,
        alignment: Layout.Alignment,
        lineSpacingMultiplier: Float,
        justify: Boolean,
    ): StaticLayout {
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(1))
            .setAlignment(alignment)
            .setLineSpacing(0f, lineSpacingMultiplier)
            .setIncludePad(false)
            .apply {
                if (justify && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
                }
            }
            .build()
    }

    suspend fun savePngToMediaStore(
        context: Context,
        bitmap: Bitmap,
        fileName: String,
    ): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        "${Environment.DIRECTORY_PICTURES}/Tinta Sastra",
                    )
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                ?: error("Gagal membuat berkas gambar di galeri")

            resolver.openOutputStream(imageUri)?.use { out ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                    error("Gagal mengompresi PNG")
                }
            } ?: error("Gagal membuka aliran keluaran gambar")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(imageUri, contentValues, null, null)
            }
            imageUri
        }
    }

    suspend fun writePngToStream(
        bitmap: Bitmap,
        outputStream: OutputStream,
    ): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            outputStream.use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
        }.getOrDefault(false)
    }

    suspend fun createShareablePngUri(
        context: Context,
        bitmap: Bitmap,
        fileName: String,
    ): Uri? = withContext(Dispatchers.IO) {
        runCatching {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val outFile = File(exportDir, fileName)
            outFile.outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outFile,
            )
        }.getOrNull()
    }
}
