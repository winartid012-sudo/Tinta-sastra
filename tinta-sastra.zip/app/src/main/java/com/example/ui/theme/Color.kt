package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Organic Literary Palette (Light - Default)
val CreamCanvas = Color(0xFFFBF7F0)
val PaperSurface = Color(0xFFF3ECE0)
val PaperElevated = Color(0xFFFFFFFF)
val PaperBorder = Color(0xFFE2D6C3)

val EspressoInk = Color(0xFF241C18)
val SepiaInk = Color(0xFF6B5C52)
val MutedTaupe = Color(0xFF9C8D82)

val TerracottaPrimary = Color(0xFF9A4832)
val TerracottaContainer = Color(0xFFF3DDD6)
val OnTerracottaContainer = Color(0xFF471A0E)

val SageSecondary = Color(0xFF566B5D)
val SageContainer = Color(0xFFDCE6DF)
val OnSageContainer = Color(0xFF1D2B22)

val AmberTertiary = Color(0xFFB57C34)
val AmberContainer = Color(0xFFF6E7CE)
val OnAmberContainer = Color(0xFF3E2607)

// Midnight Ink Palette (Dark)
val MidnightCanvas = Color(0xFF131210)
val MidnightSurface = Color(0xFF1D1A17)
val MidnightElevated = Color(0xFF27231F)
val MidnightBorder = Color(0xFF38322C)

val WarmIvoryInk = Color(0xFFF2EAE0)
val SoftAshInk = Color(0xFFB5A99B)

val TerracottaLight = Color(0xFFE08C74)
val TerracottaDarkContainer = Color(0xFF572619)
val OnTerracottaDarkContainer = Color(0xFFFFDAD0)

val SageLight = Color(0xFF9BB4A3)
val SageDarkContainer = Color(0xFF2B3B30)
val OnSageDarkContainer = Color(0xFFD2E5D8)

val AmberGoldLight = Color(0xFFE2B46E)
val AmberDarkContainer = Color(0xFF4E3412)
val OnAmberDarkContainer = Color(0xFFFFE0B2)
