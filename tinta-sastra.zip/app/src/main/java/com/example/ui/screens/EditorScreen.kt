package com.example.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignJustify
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.MoodCategory
import com.example.model.TextAlignOption
import com.example.ui.components.BackgroundCustomizationSheet
import com.example.ui.components.ExportCardSheet
import com.example.ui.components.LiteraryCanvasBackground
import com.example.ui.components.TypographyFormatSheet
import com.example.ui.theme.toComposeFontFamily
import com.example.util.formatIndonesianFullDate
import com.example.viewmodel.AutoSaveState
import com.example.viewmodel.EditorUiState
import com.example.viewmodel.EditorViewModel

private enum class ActiveEditorSheet {
    NONE,
    TYPOGRAPHY,
    BACKGROUND,
    EXPORT,
}

@Composable
fun EditorScreen(
    uiState: EditorUiState,
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit,
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var activeSheet by remember { mutableStateOf(ActiveEditorSheet.NONE) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var pendingLegacyBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val legacyCreateDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("image/png"),
    ) { uri ->
        val bmp = pendingLegacyBitmap
        pendingLegacyBitmap = null
        if (uri != null && bmp != null) {
            viewModel.saveLegacyBitmapToUri(context, bmp, uri)
        }
    }

    LaunchedEffect(uiState.exportMessage) {
        val msg = uiState.exportMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearExportMessage()
        }
    }

    BackHandler {
        viewModel.flushSaveSync()
        onNavigateBack()
    }

    if (uiState.isLoading) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator()
        }
        return
    }

    val note = uiState.note
    val bgStyle = note.bgStyle
    val inkColor = Color(note.colorMode.resolveHex(bgStyle))
    val mutedInk = inkColor.copy(alpha = 0.65f)
    val fontFamily = note.font.toComposeFontFamily()
    val composeAlign = when (note.align) {
        TextAlignOption.LEFT -> TextAlign.Start
        TextAlignOption.CENTER -> TextAlign.Center
        TextAlignOption.RIGHT -> TextAlign.End
        TextAlignOption.JUSTIFY -> TextAlign.Justify
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        containerColor = Color.Transparent,
    ) { innerPadding ->
        LiteraryCanvasBackground(
            style = bgStyle,
            customImagePath = note.customImagePath,
            blurRadius = note.backgroundBlur,
            overlayOpacity = note.overlayOpacity,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding(),
            ) {
                // Top Bar
                EditorTopBar(
                    isPinned = note.isPinned,
                    autoSaveState = uiState.autoSaveState,
                    inkColor = inkColor,
                    isLightSurface = bgStyle.defaultDarkText && note.overlayOpacity < 0.3f,
                    onBack = {
                        viewModel.flushSaveSync()
                        onNavigateBack()
                    },
                    onTogglePin = viewModel::togglePinned,
                    onOpenExport = { activeSheet = ActiveEditorSheet.EXPORT },
                    onRequestDelete = { showDeleteConfirm = true },
                )

                // Scrollable Writing Canvas
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    contentAlignment = Alignment.TopCenter,
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 680.dp)
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        // Mood Tag Selector Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            MoodCategory.entries.forEach { mood ->
                                val selected = note.mood == mood
                                FilterChip(
                                    selected = selected,
                                    onClick = { viewModel.updateMood(mood) },
                                    label = { Text(mood.label, style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(mood.tintHex),
                                        selectedLabelColor = Color(mood.accentHex),
                                        containerColor = inkColor.copy(alpha = 0.08f),
                                        labelColor = inkColor.copy(alpha = 0.78f),
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = selected,
                                        borderColor = inkColor.copy(alpha = 0.16f),
                                    ),
                                    modifier = Modifier.testTag("editor_mood_${mood.name.lowercase()}"),
                                )
                            }
                        }

                        // Title Field
                        BasicTextField(
                            value = note.title,
                            onValueChange = viewModel::updateTitle,
                            textStyle = TextStyle(
                                fontFamily = fontFamily,
                                fontSize = (note.fontSizeSp + 6f).sp,
                                lineHeight = ((note.fontSizeSp + 6f) * 1.28f).sp,
                                fontWeight = FontWeight.Bold,
                                color = inkColor,
                                textAlign = composeAlign,
                            ),
                            cursorBrush = SolidColor(inkColor),
                            decorationBox = { inner ->
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    if (note.title.isEmpty()) {
                                        Text(
                                            text = stringResource(R.string.title_hint),
                                            fontFamily = fontFamily,
                                            fontSize = (note.fontSizeSp + 6f).sp,
                                            fontWeight = FontWeight.Bold,
                                            color = mutedInk,
                                            textAlign = composeAlign,
                                            modifier = Modifier.fillMaxWidth(),
                                        )
                                    }
                                    inner()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("editor_title_input"),
                        )

                        HorizontalDivider(color = inkColor.copy(alpha = 0.18f), thickness = 1.dp)

                        // Body Field
                        val bodyLineHeight = (note.fontSizeSp * note.lineHeightMultiplier).sp
                        val bodyLetterSpacing = (note.fontSizeSp * note.letterSpacingEm).sp
                        BasicTextField(
                            value = note.content,
                            onValueChange = viewModel::updateContent,
                            textStyle = TextStyle(
                                fontFamily = fontFamily,
                                fontSize = note.fontSizeSp.sp,
                                lineHeight = bodyLineHeight,
                                letterSpacing = bodyLetterSpacing,
                                fontWeight = if (note.isBold) FontWeight.Bold else FontWeight.Normal,
                                fontStyle = if (note.isItalic) FontStyle.Italic else FontStyle.Normal,
                                textDecoration = if (note.isUnderline) TextDecoration.Underline else TextDecoration.None,
                                textAlign = composeAlign,
                                color = inkColor,
                            ),
                            cursorBrush = SolidColor(inkColor),
                            decorationBox = { inner ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 16.dp),
                                ) {
                                    if (note.content.isEmpty()) {
                                        Text(
                                            text = stringResource(R.string.body_hint),
                                            fontFamily = fontFamily,
                                            fontSize = note.fontSizeSp.sp,
                                            lineHeight = bodyLineHeight,
                                            color = mutedInk,
                                            textAlign = composeAlign,
                                            modifier = Modifier.fillMaxWidth(),
                                        )
                                    }
                                    inner()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("editor_body_input"),
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Pen Name & Auto Date Footer
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "—",
                                fontFamily = fontFamily,
                                fontSize = 15.sp,
                                color = mutedInk,
                            )
                            BasicTextField(
                                value = note.penName,
                                onValueChange = viewModel::updatePenName,
                                singleLine = true,
                                textStyle = TextStyle(
                                    fontFamily = fontFamily,
                                    fontSize = 15.sp,
                                    fontStyle = FontStyle.Italic,
                                    color = inkColor.copy(alpha = 0.85f),
                                ),
                                cursorBrush = SolidColor(inkColor),
                                decorationBox = { inner ->
                                    Box {
                                        if (note.penName.isEmpty()) {
                                            Text(
                                                text = stringResource(R.string.pen_name_hint),
                                                fontFamily = fontFamily,
                                                fontSize = 15.sp,
                                                fontStyle = FontStyle.Italic,
                                                color = mutedInk,
                                            )
                                        }
                                        inner()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("editor_pen_name_input"),
                            )
                            Text(
                                text = formatIndonesianFullDate(note.updatedAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = mutedInk,
                            )
                        }
                    }
                }

                // Bottom Metrics & Formatting Dock
                EditorBottomDock(
                    metricsText = "${uiState.metrics.words} kata • ${uiState.metrics.lines} baris • ${uiState.metrics.stanzas} bait • ~${uiState.metrics.readMinutes} mnt baca",
                    isBold = note.isBold,
                    isItalic = note.isItalic,
                    isUnderline = note.isUnderline,
                    align = note.align,
                    fontLabel = note.font.displayName,
                    onToggleBold = viewModel::toggleBold,
                    onToggleItalic = viewModel::toggleItalic,
                    onToggleUnderline = viewModel::toggleUnderline,
                    onCycleAlign = {
                        val all = TextAlignOption.entries
                        val next = all[(all.indexOf(note.align) + 1) % all.size]
                        viewModel.updateAlignment(next)
                    },
                    onOpenTypography = { activeSheet = ActiveEditorSheet.TYPOGRAPHY },
                    onOpenBackground = { activeSheet = ActiveEditorSheet.BACKGROUND },
                    onOpenExport = { activeSheet = ActiveEditorSheet.EXPORT },
                )
            }
        }
    }

    when (activeSheet) {
        ActiveEditorSheet.TYPOGRAPHY -> TypographyFormatSheet(
            note = note,
            onToggleBold = viewModel::toggleBold,
            onToggleItalic = viewModel::toggleItalic,
            onToggleUnderline = viewModel::toggleUnderline,
            onSelectAlign = viewModel::updateAlignment,
            onFontSizeChange = viewModel::updateFontSize,
            onLineHeightChange = viewModel::updateLineHeight,
            onLetterSpacingChange = viewModel::updateLetterSpacing,
            onSelectFont = viewModel::updateFont,
            onDismiss = { activeSheet = ActiveEditorSheet.NONE },
        )

        ActiveEditorSheet.BACKGROUND -> BackgroundCustomizationSheet(
            note = note,
            isUploadingImage = uiState.isUploadingImage,
            onSelectBackground = viewModel::updateBackgroundStyle,
            onCustomImagePicked = viewModel::onCustomImagePicked,
            onBlurChange = viewModel::updateBackgroundBlur,
            onOverlayChange = viewModel::updateOverlayOpacity,
            onTextColorModeChange = viewModel::updateTextColorMode,
            onDismiss = { activeSheet = ActiveEditorSheet.NONE },
        )

        ActiveEditorSheet.EXPORT -> ExportCardSheet(
            note = note,
            exportBusy = uiState.exportBusy,
            onRenderPreview = { ratio, watermark ->
                viewModel.renderPreviewBitmap(context, ratio, watermark)
            },
            onDownloadPng = { ratio, watermark ->
                viewModel.exportToGallery(
                    context = context,
                    ratio = ratio,
                    includeWatermark = watermark,
                    onLegacySaveNeeded = { bmp, suggestedName ->
                        pendingLegacyBitmap = bmp
                        legacyCreateDocumentLauncher.launch(suggestedName)
                    },
                )
            },
            onSharePng = { ratio, watermark ->
                viewModel.shareCard(context, ratio, watermark) { uri ->
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Bagikan Kartu Sastra"))
                }
            },
            onDismiss = { activeSheet = ActiveEditorSheet.NONE },
        )

        ActiveEditorSheet.NONE -> Unit
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(stringResource(R.string.delete_confirm_title)) },
            text = { Text(stringResource(R.string.delete_confirm_message)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        viewModel.deleteCurrentNote(onNavigateBack)
                    },
                ) {
                    Text(
                        text = stringResource(R.string.confirm_delete),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }
}

@Composable
private fun EditorTopBar(
    isPinned: Boolean,
    autoSaveState: AutoSaveState,
    inkColor: Color,
    isLightSurface: Boolean,
    onBack: () -> Unit,
    onTogglePin: () -> Unit,
    onOpenExport: () -> Unit,
    onRequestDelete: () -> Unit,
) {
    val barBg = if (isLightSurface) {
        Color.White.copy(alpha = 0.35f)
    } else {
        Color.Black.copy(alpha = 0.25f)
    }

    Surface(
        color = barBg,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("editor_back_button"),
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Kembali ke Pustaka",
                        tint = inkColor,
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircleOutline,
                        contentDescription = null,
                        tint = inkColor.copy(alpha = 0.65f),
                        modifier = Modifier.size(14.dp),
                    )
                    Text(
                        text = when (autoSaveState) {
                            AutoSaveState.SAVING -> stringResource(R.string.autosave_saving)
                            else -> stringResource(R.string.autosave_saved)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = inkColor.copy(alpha = 0.72f),
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onTogglePin,
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("editor_pin_button"),
                ) {
                    Icon(
                        imageVector = if (isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                        contentDescription = if (isPinned) "Lepas sematan" else "Sematkan",
                        tint = if (isPinned) Color(0xFFD68D3B) else inkColor,
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .testTag("save_as_image_button")
                        .clickable(onClick = onOpenExport),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(16.dp),
                        )
                        Text(
                            text = "Gambar",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimary,
                        )
                    }
                }

                IconButton(
                    onClick = onRequestDelete,
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("editor_delete_button"),
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = stringResource(R.string.delete_note),
                        tint = inkColor,
                    )
                }
            }
        }
    }
}

@Composable
private fun EditorBottomDock(
    metricsText: String,
    isBold: Boolean,
    isItalic: Boolean,
    isUnderline: Boolean,
    align: TextAlignOption,
    fontLabel: String,
    onToggleBold: () -> Unit,
    onToggleItalic: () -> Unit,
    onToggleUnderline: () -> Unit,
    onCycleAlign: () -> Unit,
    onOpenTypography: () -> Unit,
    onOpenBackground: () -> Unit,
    onOpenExport: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        tonalElevation = 6.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = metricsText,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .testTag("editor_metrics_text"),
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                DockMiniToggle(
                    selected = isBold,
                    contentDescription = "Tebal",
                    tag = "dock_bold",
                    onClick = onToggleBold,
                ) {
                    Icon(Icons.Default.FormatBold, contentDescription = null, modifier = Modifier.size(18.dp))
                }
                DockMiniToggle(
                    selected = isItalic,
                    contentDescription = "Miring",
                    tag = "dock_italic",
                    onClick = onToggleItalic,
                ) {
                    Icon(Icons.Default.FormatItalic, contentDescription = null, modifier = Modifier.size(18.dp))
                }
                DockMiniToggle(
                    selected = isUnderline,
                    contentDescription = "Garis bawah",
                    tag = "dock_underline",
                    onClick = onToggleUnderline,
                ) {
                    Icon(Icons.Default.FormatUnderlined, contentDescription = null, modifier = Modifier.size(18.dp))
                }

                val alignIcon = when (align) {
                    TextAlignOption.LEFT -> Icons.AutoMirrored.Filled.FormatAlignLeft
                    TextAlignOption.CENTER -> Icons.Default.FormatAlignCenter
                    TextAlignOption.RIGHT -> Icons.AutoMirrored.Filled.FormatAlignRight
                    TextAlignOption.JUSTIFY -> Icons.Default.FormatAlignJustify
                }
                DockMiniToggle(
                    selected = false,
                    contentDescription = "Perataan: ${align.label}",
                    tag = "dock_align",
                    onClick = onCycleAlign,
                ) {
                    Icon(alignIcon, contentDescription = null, modifier = Modifier.size(18.dp))
                }

                Spacer(modifier = Modifier.width(2.dp))

                DockActionPill(
                    icon = Icons.Default.TextFields,
                    label = fontLabel,
                    tag = "dock_typography",
                    onClick = onOpenTypography,
                )
                DockActionPill(
                    icon = Icons.Default.Palette,
                    label = "Kertas & Latar",
                    tag = "dock_background",
                    onClick = onOpenBackground,
                )
                DockActionPill(
                    icon = Icons.Default.Image,
                    label = "Ekspor PNG",
                    tag = "dock_export",
                    onClick = onOpenExport,
                )
            }
        }
    }
}

@Composable
private fun DockMiniToggle(
    selected: Boolean,
    contentDescription: String,
    tag: String,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer
        } else {
            MaterialTheme.colorScheme.surfaceVariant
        },
        contentColor = if (selected) {
            MaterialTheme.colorScheme.onPrimaryContainer
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        },
        modifier = Modifier
            .size(42.dp)
            .testTag(tag)
            .clickable(onClick = onClick),
    ) {
        Box(contentAlignment = Alignment.Center) {
            icon()
        }
    }
}

@Composable
private fun DockActionPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tag: String,
    onClick: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier
            .height(42.dp)
            .testTag(tag)
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(17.dp),
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
            )
        }
    }
}
