package com.example.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.PoemNoteEntity
import com.example.data.PoemRepository
import com.example.model.BackgroundStyle
import com.example.model.ExportRatio
import com.example.model.LiteraryFont
import com.example.model.MoodCategory
import com.example.model.TextAlignOption
import com.example.model.TextColorMode
import com.example.model.WritingMetrics
import com.example.model.computeWritingMetrics
import com.example.util.CardExporter
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AutoSaveState {
    IDLE,
    SAVING,
    SAVED,
}

data class EditorUiState(
    val isLoading: Boolean = true,
    val note: PoemNoteEntity = PoemNoteEntity(),
    val metrics: WritingMetrics = WritingMetrics(0, 0, 0, 0),
    val autoSaveState: AutoSaveState = AutoSaveState.IDLE,
    val isUploadingImage: Boolean = false,
    val exportBusy: Boolean = false,
    val exportMessage: String? = null,
)

class EditorViewModel(
    private val noteId: Long,
    private val repository: PoemRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private var autoSaveJob: Job? = null

    init {
        viewModelScope.launch {
            val loaded = if (noteId > 0L) {
                repository.getNoteById(noteId)
            } else {
                null
            } ?: run {
                val createdId = repository.createNote()
                repository.getNoteById(createdId) ?: PoemNoteEntity(id = createdId)
            }

            _uiState.value = EditorUiState(
                isLoading = false,
                note = loaded,
                metrics = computeWritingMetrics(loaded.title, loaded.content),
                autoSaveState = AutoSaveState.SAVED,
            )
        }
    }

    fun updateTitle(title: String) {
        updateNoteDebounced { it.copy(title = title) }
    }

    fun updateContent(content: String) {
        updateNoteDebounced { it.copy(content = content) }
    }

    fun updatePenName(penName: String) {
        updateNoteDebounced { it.copy(penName = penName) }
    }

    fun updateMood(mood: MoodCategory) {
        updateNoteImmediate { it.copy(moodCategory = mood.name) }
    }

    fun togglePinned() {
        updateNoteImmediate { it.copy(isPinned = !it.isPinned) }
    }

    fun toggleBold() {
        updateNoteImmediate { it.copy(isBold = !it.isBold) }
    }

    fun toggleItalic() {
        updateNoteImmediate { it.copy(isItalic = !it.isItalic) }
    }

    fun toggleUnderline() {
        updateNoteImmediate { it.copy(isUnderline = !it.isUnderline) }
    }

    fun updateAlignment(align: TextAlignOption) {
        updateNoteImmediate { it.copy(textAlign = align.name) }
    }

    fun updateFont(font: LiteraryFont) {
        updateNoteImmediate { it.copy(fontName = font.name) }
    }

    fun updateFontSize(sizeSp: Float) {
        updateNoteDebounced { it.copy(fontSizeSp = sizeSp.coerceIn(13f, 34f)) }
    }

    fun updateLineHeight(multiplier: Float) {
        updateNoteDebounced { it.copy(lineHeightMultiplier = multiplier.coerceIn(1.1f, 2.3f)) }
    }

    fun updateLetterSpacing(em: Float) {
        updateNoteDebounced { it.copy(letterSpacingEm = em.coerceIn(-0.02f, 0.25f)) }
    }

    fun updateBackgroundStyle(style: BackgroundStyle) {
        updateNoteImmediate { current ->
            val nextOverlay = if (style.isPhoto && current.overlayOpacity == 0f) {
                style.defaultOverlayOpacity
            } else if (!style.isPhoto) {
                0f
            } else {
                current.overlayOpacity
            }
            current.copy(
                backgroundStyle = style.name,
                overlayOpacity = nextOverlay,
                backgroundBlur = if (style.isPhoto) current.backgroundBlur else 0f,
            )
        }
    }

    fun updateBackgroundBlur(blur: Float) {
        updateNoteDebounced { it.copy(backgroundBlur = blur.coerceIn(0f, 25f)) }
    }

    fun updateOverlayOpacity(opacity: Float) {
        updateNoteDebounced { it.copy(overlayOpacity = opacity.coerceIn(0f, 0.85f)) }
    }

    fun updateTextColorMode(mode: TextColorMode) {
        updateNoteImmediate { it.copy(textColorMode = mode.name) }
    }

    fun onCustomImagePicked(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingImage = true) }
            val savedPath = repository.copyPickedImageToInternalStorage(uri)
            if (savedPath != null) {
                updateNoteImmediate { current ->
                    current.copy(
                        backgroundStyle = BackgroundStyle.CUSTOM_IMAGE.name,
                        customImagePath = savedPath,
                        overlayOpacity = if (current.overlayOpacity < 0.1f) {
                            BackgroundStyle.CUSTOM_IMAGE.defaultOverlayOpacity
                        } else {
                            current.overlayOpacity
                        },
                    )
                }
            }
            _uiState.update { it.copy(isUploadingImage = false) }
        }
    }

    fun deleteCurrentNote(onDeleted: () -> Unit) {
        val currentId = _uiState.value.note.id
        autoSaveJob?.cancel()
        viewModelScope.launch {
            if (currentId > 0L) {
                repository.deleteNote(currentId)
            }
            onDeleted()
        }
    }

    fun flushSaveSync() {
        val note = _uiState.value.note
        if (note.id <= 0L) return
        autoSaveJob?.cancel()
        viewModelScope.launch {
            repository.saveNote(note)
        }
    }

    suspend fun renderPreviewBitmap(
        context: Context,
        ratio: ExportRatio,
        includeWatermark: Boolean,
    ): Bitmap {
        return CardExporter.renderLiteraryCardBitmap(
            context = context,
            note = _uiState.value.note,
            ratio = ratio,
            includeWatermark = includeWatermark,
        )
    }

    fun exportToGallery(
        context: Context,
        ratio: ExportRatio,
        includeWatermark: Boolean,
        onLegacySaveNeeded: (Bitmap, String) -> Unit,
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(exportBusy = true, exportMessage = null) }
            val note = _uiState.value.note
            val bitmap = CardExporter.renderLiteraryCardBitmap(
                context = context,
                note = note,
                ratio = ratio,
                includeWatermark = includeWatermark,
            )
            val safeSlug = note.title.ifBlank { "karya" }
                .lowercase()
                .replace(Regex("[^a-z0-9]+"), "_")
                .trim('_')
                .take(24)
                .ifEmpty { "karya" }
            val fileName = "tinta_sastra_${safeSlug}_${ratio.label.replace(":", "x")}_${System.currentTimeMillis()}.png"

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val res = CardExporter.savePngToMediaStore(context, bitmap, fileName)
                _uiState.update {
                    it.copy(
                        exportBusy = false,
                        exportMessage = if (res.isSuccess) {
                            "Kartu PNG tersimpan di Galeri (Pictures/Tinta Sastra)"
                        } else {
                            "Gagal menyimpan gambar: ${res.exceptionOrNull()?.localizedMessage ?: "Kesalahan tidak diketahui"}"
                        },
                    )
                }
            } else {
                _uiState.update { it.copy(exportBusy = false) }
                onLegacySaveNeeded(bitmap, fileName)
            }
        }
    }

    fun saveLegacyBitmapToUri(context: Context, bitmap: Bitmap, uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(exportBusy = true) }
            val ok = context.contentResolver.openOutputStream(uri)?.let { out ->
                CardExporter.writePngToStream(bitmap, out)
            } ?: false
            _uiState.update {
                it.copy(
                    exportBusy = false,
                    exportMessage = if (ok) "Kartu PNG berhasil disimpan" else "Gagal menulis berkas PNG",
                )
            }
        }
    }

    fun shareCard(
        context: Context,
        ratio: ExportRatio,
        includeWatermark: Boolean,
        onShareUriReady: (Uri) -> Unit,
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(exportBusy = true, exportMessage = null) }
            val note = _uiState.value.note
            val bitmap = CardExporter.renderLiteraryCardBitmap(
                context = context,
                note = note,
                ratio = ratio,
                includeWatermark = includeWatermark,
            )
            val fileName = "tinta_sastra_share_${System.currentTimeMillis()}.png"
            val uri = CardExporter.createShareablePngUri(context, bitmap, fileName)
            _uiState.update { it.copy(exportBusy = false) }
            if (uri != null) {
                onShareUriReady(uri)
            } else {
                _uiState.update { it.copy(exportMessage = "Gagal menyiapkan gambar untuk dibagikan") }
            }
        }
    }

    fun clearExportMessage() {
        _uiState.update { it.copy(exportMessage = null) }
    }

    private fun updateNoteDebounced(transform: (PoemNoteEntity) -> PoemNoteEntity) {
        _uiState.update { state ->
            val updated = transform(state.note).copy(updatedAt = System.currentTimeMillis())
            state.copy(
                note = updated,
                metrics = computeWritingMetrics(updated.title, updated.content),
                autoSaveState = AutoSaveState.SAVING,
            )
        }
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(380L)
            val current = _uiState.value.note
            if (current.id > 0L) {
                repository.saveNote(current)
            }
            _uiState.update { it.copy(autoSaveState = AutoSaveState.SAVED) }
        }
    }

    private fun updateNoteImmediate(transform: (PoemNoteEntity) -> PoemNoteEntity) {
        autoSaveJob?.cancel()
        _uiState.update { state ->
            val updated = transform(state.note).copy(updatedAt = System.currentTimeMillis())
            state.copy(
                note = updated,
                metrics = computeWritingMetrics(updated.title, updated.content),
                autoSaveState = AutoSaveState.SAVING,
            )
        }
        viewModelScope.launch {
            val current = _uiState.value.note
            if (current.id > 0L) {
                repository.saveNote(current)
            }
            _uiState.update { it.copy(autoSaveState = AutoSaveState.SAVED) }
        }
    }

    override fun onCleared() {
        autoSaveJob?.cancel()
        super.onCleared()
    }
}

class EditorViewModelFactory(
    private val noteId: Long,
    private val repository: PoemRepository,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return EditorViewModel(noteId, repository) as T
    }
}
