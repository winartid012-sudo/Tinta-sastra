package com.example.model

import androidx.annotation.DrawableRes
import androidx.annotation.FontRes
import com.example.R

enum class MoodCategory(
    val label: String,
    val accentHex: Long,
    val tintHex: Long,
) {
    RINDU("Rindu", 0xFFB5654D, 0xFFF7E5DF),
    MELANKOLIS("Melankolis", 0xFF536B7E, 0xFFE4ECF2),
    ROMANTIS("Romantis", 0xFFA6526A, 0xFFF5E3E8),
    FILOSOFI("Filosofi", 0xFF6B6E4F, 0xFFECEEE3),
    BEBAS("Bebas", 0xFF8A6E4B, 0xFFF3EBDF);

    companion object {
        fun fromName(name: String?): MoodCategory =
            entries.firstOrNull { it.name == name } ?: BEBAS
    }
}

enum class LiteraryFontCategory(val label: String) {
    SERIF("Serif Klasik"),
    TYPEWRITER("Mesin Ketik Vintage"),
    HANDWRITING("Tulisan Tangan"),
    SANS("Sans-Serif Modern"),
}

enum class LiteraryFont(
    val displayName: String,
    val category: LiteraryFontCategory,
    @param:FontRes val fontRes: Int,
    val sampleLine: String,
) {
    PLAYFAIR_DISPLAY(
        "Playfair Display",
        LiteraryFontCategory.SERIF,
        R.font.playfair_display,
        "Di antara senja dan aksara",
    ),
    LORA(
        "Lora",
        LiteraryFontCategory.SERIF,
        R.font.lora,
        "Membaca sunyi di sela hujan",
    ),
    MERRIWEATHER(
        "Merriweather",
        LiteraryFontCategory.SERIF,
        R.font.merriweather,
        "Kata yang tak sempat terucap",
    ),
    COURIER_PRIME(
        "Courier Prime",
        LiteraryFontCategory.TYPEWRITER,
        R.font.courier_prime,
        "Catatan mesin tik tengah malam",
    ),
    SPECIAL_ELITE(
        "Special Elite",
        LiteraryFontCategory.TYPEWRITER,
        R.font.special_elite,
        "Jejak tinta di kertas usang",
    ),
    DANCING_SCRIPT(
        "Dancing Script",
        LiteraryFontCategory.HANDWRITING,
        R.font.dancing_script,
        "Surat kecil untukmu yang jauh",
    ),
    GREAT_VIBES(
        "Great Vibes",
        LiteraryFontCategory.HANDWRITING,
        R.font.great_vibes,
        "Asmara dalam bait lembut",
    ),
    CAVEAT(
        "Caveat",
        LiteraryFontCategory.HANDWRITING,
        R.font.caveat,
        "Coretan tangan di tepi buku",
    ),
    PLUS_JAKARTA_SANS(
        "Plus Jakarta Sans",
        LiteraryFontCategory.SANS,
        R.font.plus_jakarta_sans,
        "Prosa modern yang jernih",
    );

    companion object {
        fun fromName(name: String?): LiteraryFont =
            entries.firstOrNull { it.name == name } ?: LORA
    }
}

enum class TextAlignOption(val label: String) {
    LEFT("Kiri"),
    CENTER("Tengah"),
    RIGHT("Kanan"),
    JUSTIFY("Rata");

    companion object {
        fun fromName(name: String?): TextAlignOption =
            entries.firstOrNull { it.name == name } ?: LEFT
    }
}

enum class BackgroundStyle(
    val label: String,
    val isPhoto: Boolean,
    @param:DrawableRes val drawableRes: Int?,
    val baseColorHex: Long,
    val defaultDarkText: Boolean,
    val defaultOverlayOpacity: Float,
) {
    CLEAN_WHITE("Putih Bersih", false, null, 0xFFFFFFFF, true, 0.0f),
    WARM_PAPER("Krem Klasik", false, null, 0xFFF7F0E2, true, 0.0f),
    VINTAGE_AGED("Kertas Vintage", false, null, 0xFFE9D8B8, true, 0.0f),
    MIDNIGHT_INK("Tinta Malam", false, null, 0xFF16181E, false, 0.0f),
    IMG_SENJA("Senja", true, R.drawable.img_bg_senja, 0xFF422F2B, false, 0.36f),
    IMG_HUJAN("Hujan", true, R.drawable.img_bg_hujan, 0xFF212B38, false, 0.42f),
    IMG_HUTAN("Hutan Berkabut", true, R.drawable.img_bg_hutan, 0xFF26332D, false, 0.40f),
    IMG_KERTAS_KUSUT("Kertas Kusut", true, R.drawable.img_bg_kertas_kusut, 0xFFE6D9BF, true, 0.06f),
    CUSTOM_IMAGE("Foto Galeri", true, null, 0xFF231F1D, false, 0.42f);

    companion object {
        fun fromName(name: String?): BackgroundStyle =
            entries.firstOrNull { it.name == name } ?: WARM_PAPER
    }
}

enum class TextColorMode(val label: String, val colorHex: Long?) {
    AUTO("Otomatis", null),
    DARK_INK("Tinta Gelap", 0xFF251E19),
    WARM_IVORY("Putih Hangat", 0xFFFAF6EE),
    GOLD_SEPIA("Emas Sepia", 0xFFE9D2A6);

    fun resolveHex(backgroundStyle: BackgroundStyle): Long {
        colorHex?.let { return it }
        return if (backgroundStyle.defaultDarkText) 0xFF251E19 else 0xFFFAF6EE
    }

    companion object {
        fun fromName(name: String?): TextColorMode =
            entries.firstOrNull { it.name == name } ?: AUTO
    }
}

enum class ExportRatio(
    val label: String,
    val subtitle: String,
    val widthPx: Int,
    val heightPx: Int,
    val aspectFloat: Float,
) {
    SQUARE("1:1", "Persegi • Feed", 1080, 1080, 1f),
    PORTRAIT("4:5", "Potret • IG", 1080, 1350, 0.8f),
    STORY("9:16", "Story • Status WA", 1080, 1920, 9f / 16f),
}

data class WritingMetrics(
    val words: Int,
    val lines: Int,
    val stanzas: Int,
    val readMinutes: Int,
)

fun computeWritingMetrics(title: String, body: String): WritingMetrics {
    val trimmedBody = body.trim()
    val combined = listOf(title.trim(), trimmedBody).filter { it.isNotEmpty() }.joinToString(" ")
    val wordCount = if (combined.isEmpty()) {
        0
    } else {
        combined.split(Regex("\\s+")).count { it.isNotBlank() }
    }
    val nonEmptyLines = if (trimmedBody.isEmpty()) {
        0
    } else {
        trimmedBody.lines().count { it.isNotBlank() }
    }
    val stanzas = if (trimmedBody.isEmpty()) {
        0
    } else {
        trimmedBody.split(Regex("\\n\\s*\\n")).count { it.isNotBlank() }
    }
    val readMinutes = if (wordCount == 0) 0 else kotlin.math.max(1, (wordCount + 169) / 170)
    return WritingMetrics(
        words = wordCount,
        lines = nonEmptyLines,
        stanzas = stanzas,
        readMinutes = readMinutes,
    )
}
