package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val indonesianLocale = Locale.Builder().setLanguage("id").setRegion("ID").build()

fun formatIndonesianFullDate(timestampMillis: Long): String {
    val formatter = SimpleDateFormat("d MMMM yyyy", indonesianLocale)
    return formatter.format(Date(timestampMillis))
}

fun formatIndonesianShortDate(timestampMillis: Long): String {
    val formatter = SimpleDateFormat("d MMM yyyy", indonesianLocale)
    return formatter.format(Date(timestampMillis))
}
