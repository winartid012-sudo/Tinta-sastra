package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PoemNoteDao {
    @Query("SELECT * FROM poem_notes ORDER BY isPinned DESC, updatedAt DESC")
    fun observeAllNotes(): Flow<List<PoemNoteEntity>>

    @Query("SELECT * FROM poem_notes WHERE isPinned = 1 ORDER BY updatedAt DESC")
    fun observePinnedNotes(): Flow<List<PoemNoteEntity>>

    @Query("SELECT * FROM poem_notes WHERE id = :id LIMIT 1")
    suspend fun getNoteById(id: Long): PoemNoteEntity?

    @Query("SELECT * FROM poem_notes WHERE id = :id LIMIT 1")
    fun observeNoteById(id: Long): Flow<PoemNoteEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: PoemNoteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(notes: List<PoemNoteEntity>)

    @Update
    suspend fun updateNote(note: PoemNoteEntity)

    @Query("UPDATE poem_notes SET isPinned = :pinned, updatedAt = :updatedAt WHERE id = :id")
    suspend fun setPinned(id: Long, pinned: Boolean, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM poem_notes WHERE id = :id")
    suspend fun deleteNoteById(id: Long)

    @Query("SELECT COUNT(*) FROM poem_notes")
    suspend fun countNotes(): Int
}
