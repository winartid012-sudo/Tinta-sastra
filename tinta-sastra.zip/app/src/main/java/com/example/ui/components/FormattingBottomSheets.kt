package com.example.ui.components

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignJustify
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.PoemNoteEntity
import com.example.model.BackgroundStyle
import com.example.model.ExportRatio
import com.example.model.LiteraryFont
import com.example.model.LiteraryFontCategory
import com.example.model.TextAlignOption
import com.example.model.TextColorMode
import com.example.ui.theme.toComposeFontFamily
import com.example.util.CardExporter
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TypographyFormatSheet(
    note: PoemNoteEntity,
    onToggleBold: () -> Unit,
    onToggleItalic: () -> Unit,
    onToggleUnderline: () -> Unit,
    onSelectAlign: (TextAlignOption) -> Unit,
    onFontSizeChange: (Float) -> Unit,
    onLineHeightChange: (Float) -> Unit,
    onLetterSpacingChange: (Float) -> Unit,
    onSelectFont: (LiteraryFont) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = "Tipografi & Format Teks",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface,
            )

            // Style & Alignment Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormatIconToggle(
                        icon = Icons.Default.FormatBold,
                        contentDescription = "Tebal",
                        selected = note.isBold,
                        tag = "toggle_bold",
                        onClick = onToggleBold,
                    )
                    FormatIconToggle(
                        icon = Icons.Default.FormatItalic,
                        contentDescription = "Miring",
                        selected = note.isItalic,
                        tag = "toggle_italic",
                        onClick = onToggleItalic,
                    )
                    FormatIconToggle(
                        icon = Icons.Default.FormatUnderlined,
                        contentDescription = "Garis bawah",
                        selected = note.isUnderline,
                        tag = "toggle_underline",
                        onClick = onToggleUnderline,
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        TextAlignOption.LEFT to Icons.AutoMirrored.Filled.FormatAlignLeft,
                        TextAlignOption.CENTER to Icons.Default.FormatAlignCenter,
                        TextAlignOption.RIGHT to Icons.AutoMirrored.Filled.FormatAlignRight,
                        TextAlignOption.JUSTIFY to Icons.Default.FormatAlignJustify,
                    ).forEach { (option, icon) ->
                        FormatIconToggle(
                            icon = icon,
                            contentDescription = "Rata ${option.label}",
                            selected = note.align == option,
                            tag = "align_${option.name.lowercase()}",
                            onClick = { onSelectAlign(option) },
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            // Font Size Slider
            LabeledSlider(
                label = "Ukuran Huruf",
                valueLabel = "${note.fontSizeSp.roundToInt()} sp",
                value = note.fontSizeSp,
                valueRange = 13f..32f,
                onValueChange = onFontSizeChange,
            )

            // Line Height Slider
            LabeledSlider(
                label = "Jarak Antar Baris",
                valueLabel = String.format("%.2fx", note.lineHeightMultiplier),
                value = note.lineHeightMultiplier,
                valueRange = 1.15f..2.2f,
                onValueChange = onLineHeightChange,
            )

            // Letter Spacing Slider
            LabeledSlider(
                label = "Jarak Antar Huruf",
                valueLabel = String.format("%.2f em", note.letterSpacingEm),
                value = note.letterSpacingEm,
                valueRange = -0.02f..0.22f,
                onValueChange = onLetterSpacingChange,
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Text(
                text = "Koleksi Font Sastra",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )

            LiteraryFontCategory.entries.forEach { category ->
                val fontsInCategory = LiteraryFont.entries.filter { it.category == category }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = category.label,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        fontsInCategory.forEach { font ->
                            val isSelected = note.font == font
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                },
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant
                                    },
                                ),
                                modifier = Modifier
                                    .testTag("font_${font.name.lowercase()}")
                                    .clickable { onSelectFont(font) },
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                ) {
                                    Text(
                                        text = font.displayName,
                                        fontFamily = font.toComposeFontFamily(),
                                        fontSize = 16.sp,
                                        color = if (isSelected) {
                                            MaterialTheme.colorScheme.onPrimaryContainer
                                        } else {
                                            MaterialTheme.colorScheme.onSurface
                                        },
                                    )
                                    Text(
                                        text = font.sampleLine,
                                        fontFamily = font.toComposeFontFamily(),
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BackgroundCustomizationSheet(
    note: PoemNoteEntity,
    isUploadingImage: Boolean,
    onSelectBackground: (BackgroundStyle) -> Unit,
    onCustomImagePicked: (android.net.Uri) -> Unit,
    onBlurChange: (Float) -> Unit,
    onOverlayChange: (Float) -> Unit,
    onTextColorModeChange: (TextColorMode) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) {
            onCustomImagePicked(uri)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = "Kertas & Latar Belakang",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface,
            )

            // 1. Paper Presets
            Text(
                text = "Warna & Tekstur Kertas",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val paperStyles = listOf(
                BackgroundStyle.CLEAN_WHITE,
                BackgroundStyle.WARM_PAPER,
                BackgroundStyle.VINTAGE_AGED,
                BackgroundStyle.MIDNIGHT_INK,
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                paperStyles.forEach { bg ->
                    val selected = note.bgStyle == bg
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(78.dp)
                            .testTag("bg_${bg.name.lowercase()}")
                            .clickable { onSelectBackground(bg) },
                    ) {
                        Box(
                            modifier = Modifier
                                .size(62.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(bg.baseColorHex))
                                .border(
                                    width = if (selected) 2.5.dp else 1.dp,
                                    color = if (selected) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outline
                                    },
                                    shape = RoundedCornerShape(16.dp),
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (selected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Terpilih",
                                    tint = if (bg.defaultDarkText) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        Color(0xFFFAF6EE)
                                    },
                                )
                            } else {
                                Text(
                                    text = "Aa",
                                    fontSize = 18.sp,
                                    color = if (bg.defaultDarkText) Color(0xFF251E19) else Color(0xFFFAF6EE),
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = bg.label,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 2,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }

            // 2. Aesthetic Photo Backgrounds
            Text(
                text = "Latar Foto Estetik",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val photoPresets = listOf(
                BackgroundStyle.IMG_SENJA,
                BackgroundStyle.IMG_HUJAN,
                BackgroundStyle.IMG_HUTAN,
                BackgroundStyle.IMG_KERTAS_KUSUT,
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                photoPresets.forEach { bg ->
                    val selected = note.bgStyle == bg
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(84.dp)
                            .testTag("bg_${bg.name.lowercase()}")
                            .clickable { onSelectBackground(bg) },
                    ) {
                        Box(
                            modifier = Modifier
                                .size(width = 84.dp, height = 104.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(
                                    width = if (selected) 2.5.dp else 1.dp,
                                    color = if (selected) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            bg.drawableRes?.let { resId ->
                                Image(
                                    painter = painterResource(id = resId),
                                    contentDescription = bg.label,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                            if (selected) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = bg.label,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }

            // 3. Upload Custom Image from Gallery
            OutlinedButton(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                    )
                },
                enabled = !isUploadingImage,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("upload_gallery_button"),
                shape = RoundedCornerShape(14.dp),
            ) {
                if (isUploadingImage) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Memuat foto galeri…")
                } else {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        if (note.bgStyle == BackgroundStyle.CUSTOM_IMAGE && !note.customImagePath.isNullOrBlank()) {
                            "Ganti Foto dari Galeri HP"
                        } else {
                            stringResource(R.string.upload_from_gallery)
                        },
                    )
                }
            }

            // 4. Blur & Overlay sliders (active when using any photo background)
            if (note.bgStyle.isPhoto) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                LabeledSlider(
                    label = "Tingkat Keburaman (Blur)",
                    valueLabel = "${note.backgroundBlur.roundToInt()}",
                    value = note.backgroundBlur,
                    valueRange = 0f..25f,
                    onValueChange = onBlurChange,
                )

                LabeledSlider(
                    label = "Kegelapan Lapisan (Overlay)",
                    valueLabel = "${(note.overlayOpacity * 100).roundToInt()}%",
                    value = note.overlayOpacity,
                    valueRange = 0f..0.85f,
                    onValueChange = onOverlayChange,
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            // 5. Text Color Mode
            Text(
                text = "Warna Tinta Teks",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                TextColorMode.entries.forEach { mode ->
                    FilterChip(
                        selected = note.colorMode == mode,
                        onClick = { onTextColorModeChange(mode) },
                        label = { Text(mode.label) },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportCardSheet(
    note: PoemNoteEntity,
    exportBusy: Boolean,
    onRenderPreview: suspend (ExportRatio, Boolean) -> Bitmap,
    onDownloadPng: (ExportRatio, Boolean) -> Unit,
    onSharePng: (ExportRatio, Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedRatio by remember { mutableStateOf(ExportRatio.SQUARE) }
    var includeWatermark by remember { mutableStateOf(true) }
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(note, selectedRatio, includeWatermark) {
        previewBitmap = onRenderPreview(selectedRatio, includeWatermark)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = stringResource(R.string.export_sheet_title),
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface,
            )

            // Ratio selector chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ExportRatio.entries.forEach { ratio ->
                    val selected = selectedRatio == ratio
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (selected) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        },
                        border = BorderStroke(
                            width = if (selected) 1.5.dp else 1.dp,
                            color = if (selected) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.outlineVariant
                            },
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ratio_${ratio.name.lowercase()}")
                            .clickable { selectedRatio = ratio },
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                text = ratio.label,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                },
                            )
                            Text(
                                text = ratio.subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            // Live Rendered Card Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 340.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(12.dp),
                contentAlignment = Alignment.Center,
            ) {
                val bmp = previewBitmap
                if (bmp != null) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Pratinjau kartu sastra",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .aspectRatio(selectedRatio.aspectFloat)
                            .clip(RoundedCornerShape(10.dp)),
                    )
                } else {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp))
                }
            }

            // Watermark toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Tanda Tangan Tinta Sastra",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                    )
                    Text(
                        text = "Tampilkan cap kecil di bagian bawah kartu",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = includeWatermark,
                    onCheckedChange = { includeWatermark = it },
                )
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(
                    onClick = { onSharePng(selectedRatio, includeWatermark) },
                    enabled = !exportBusy,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 50.dp)
                        .testTag("share_card_button"),
                    shape = RoundedCornerShape(14.dp),
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(stringResource(R.string.share_card))
                }

                Button(
                    onClick = { onDownloadPng(selectedRatio, includeWatermark) },
                    enabled = !exportBusy,
                    modifier = Modifier
                        .weight(1.4f)
                        .heightIn(min = 50.dp)
                        .testTag("download_png_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                    ),
                ) {
                    if (exportBusy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp,
                        )
                    } else {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(stringResource(R.string.download_png))
                }
            }
        }
    }
}

@Composable
private fun FormatIconToggle(
    icon: ImageVector,
    contentDescription: String,
    selected: Boolean,
    tag: String,
    onClick: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer
        } else {
            MaterialTheme.colorScheme.surfaceVariant
        },
        border = BorderStroke(
            width = 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
        ),
        modifier = Modifier
            .size(44.dp)
            .testTag(tag)
            .clickable(onClick = onClick),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (selected) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    valueLabel: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = valueLabel,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Slider(
            value = value.coerceIn(valueRange.start, valueRange.endInclusive),
            onValueChange = onValueChange,
            valueRange = valueRange,
        )
    }
}
