package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val TintaLightColorScheme = lightColorScheme(
    primary = TerracottaPrimary,
    onPrimary = PaperElevated,
    primaryContainer = TerracottaContainer,
    onPrimaryContainer = OnTerracottaContainer,
    secondary = SageSecondary,
    onSecondary = PaperElevated,
    secondaryContainer = SageContainer,
    onSecondaryContainer = OnSageContainer,
    tertiary = AmberTertiary,
    onTertiary = PaperElevated,
    tertiaryContainer = AmberContainer,
    onTertiaryContainer = OnAmberContainer,
    background = CreamCanvas,
    onBackground = EspressoInk,
    surface = CreamCanvas,
    onSurface = EspressoInk,
    surfaceVariant = PaperSurface,
    onSurfaceVariant = SepiaInk,
    surfaceContainerLow = PaperSurface,
    surfaceContainer = PaperSurface,
    surfaceContainerHigh = PaperElevated,
    outline = PaperBorder,
    outlineVariant = PaperBorder,
)

private val TintaDarkColorScheme = darkColorScheme(
    primary = TerracottaLight,
    onPrimary = MidnightCanvas,
    primaryContainer = TerracottaDarkContainer,
    onPrimaryContainer = OnTerracottaDarkContainer,
    secondary = SageLight,
    onSecondary = MidnightCanvas,
    secondaryContainer = SageDarkContainer,
    onSecondaryContainer = OnSageDarkContainer,
    tertiary = AmberGoldLight,
    onTertiary = MidnightCanvas,
    tertiaryContainer = AmberDarkContainer,
    onTertiaryContainer = OnAmberDarkContainer,
    background = MidnightCanvas,
    onBackground = WarmIvoryInk,
    surface = MidnightCanvas,
    onSurface = WarmIvoryInk,
    surfaceVariant = MidnightSurface,
    onSurfaceVariant = SoftAshInk,
    surfaceContainerLow = MidnightSurface,
    surfaceContainer = MidnightSurface,
    surfaceContainerHigh = MidnightElevated,
    outline = MidnightBorder,
    outlineVariant = MidnightBorder,
)

val TintaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun TintaSastraTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) TintaDarkColorScheme else TintaLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = TintaShapes,
        content = content,
    )
}
