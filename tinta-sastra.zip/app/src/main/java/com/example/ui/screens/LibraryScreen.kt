package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.PoemNoteEntity
import com.example.model.BackgroundStyle
import com.example.model.MoodCategory
import com.example.model.computeWritingMetrics
import com.example.ui.components.LiteraryCanvasBackground
import com.example.ui.theme.PlayfairDisplayFontFamily
import com.example.ui.theme.toComposeFontFamily
import com.example.util.formatIndonesianShortDate
import com.example.viewmodel.LibraryUiState
import com.example.viewmodel.StudioTemplatePreset
import com.example.viewmodel.curatedStudioPresets

@Composable
fun LibraryScreen(
    uiState: LibraryUiState,
    onSearchQueryChange: (String) -> Unit,
    onSelectMood: (MoodCategory?) -> Unit,
    onTogglePinnedFilter: () -> Unit,
    onOpenNote: (Long) -> Unit,
    onCreateBlankNote: () -> Unit,
    onCreateFromPreset: (StudioTemplatePreset) -> Unit,
    onTogglePin: (PoemNoteEntity) -> Unit,
    onDeleteNote: (Long) -> Unit,
    onUpdateDefaultPenName: (String) -> Unit,
    onToggleAppTheme: (Boolean) -> Unit,
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var notePendingDelete by remember { mutableStateOf<PoemNoteEntity?>(null) }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 640.dp

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            containerColor = MaterialTheme.colorScheme.background,
            floatingActionButton = {
                if (selectedTab != 2) {
                    ExtendedFloatingActionButton(
                        onClick = onCreateBlankNote,
                        icon = { Icon(Icons.Default.Edit, contentDescription = null) },
                        text = { Text(stringResource(R.string.new_note_fab)) },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier
                            .then(if (isWideScreen) Modifier.navigationBarsPadding() else Modifier)
                            .testTag("create_note_fab"),
                    )
                }
            },
            bottomBar = {
                if (!isWideScreen) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer,
                        tonalElevation = 4.dp,
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == 0) Icons.Filled.MenuBook else Icons.Outlined.MenuBook,
                                    contentDescription = null,
                                )
                            },
                            label = { Text(stringResource(R.string.nav_library)) },
                            modifier = Modifier.testTag("nav_library"),
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == 1) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                    contentDescription = null,
                                )
                            },
                            label = { Text(stringResource(R.string.nav_favorites)) },
                            modifier = Modifier.testTag("nav_favorites"),
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == 2) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome,
                                    contentDescription = null,
                                )
                            },
                            label = { Text(stringResource(R.string.nav_studio)) },
                            modifier = Modifier.testTag("nav_studio"),
                        )
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (isWideScreen) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier
                            .fillMaxHeight()
                            .statusBarsPadding(),
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))
                        NavigationRailItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = {
                                Icon(
                                    if (selectedTab == 0) Icons.Filled.MenuBook else Icons.Outlined.MenuBook,
                                    contentDescription = null,
                                )
                            },
                            label = { Text(stringResource(R.string.nav_library)) },
                        )
                        NavigationRailItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = {
                                Icon(
                                    if (selectedTab == 1) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                    contentDescription = null,
                                )
                            },
                            label = { Text(stringResource(R.string.nav_favorites)) },
                        )
                        NavigationRailItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = {
                                Icon(
                                    if (selectedTab == 2) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome,
                                    contentDescription = null,
                                )
                            },
                            label = { Text(stringResource(R.string.nav_studio)) },
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding(),
                ) {
                    MastheadHeader(
                        totalNotes = uiState.allNotes.size,
                        isDarkAppTheme = uiState.isDarkAppTheme,
                        onToggleDarkTheme = { onToggleAppTheme(!uiState.isDarkAppTheme) },
                    )

                    when (selectedTab) {
                        0 -> LibraryTabContent(
                            uiState = uiState,
                            isWideScreen = isWideScreen,
                            onSearchQueryChange = onSearchQueryChange,
                            onSelectMood = onSelectMood,
                            onTogglePinnedFilter = onTogglePinnedFilter,
                            onOpenNote = onOpenNote,
                            onTogglePin = onTogglePin,
                            onRequestDelete = { notePendingDelete = it },
                        )

                        1 -> FavoritesTabContent(
                            pinnedNotes = uiState.pinnedNotes,
                            isWideScreen = isWideScreen,
                            onOpenNote = onOpenNote,
                            onTogglePin = onTogglePin,
                            onRequestDelete = { notePendingDelete = it },
                        )

                        else -> StudioPresetsTabContent(
                            defaultPenName = uiState.defaultPenName,
                            isDarkAppTheme = uiState.isDarkAppTheme,
                            onUpdateDefaultPenName = onUpdateDefaultPenName,
                            onToggleAppTheme = onToggleAppTheme,
                            onCreateFromPreset = onCreateFromPreset,
                        )
                    }
                }
            }
        }
    }

    notePendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { notePendingDelete = null },
            title = { Text(stringResource(R.string.delete_confirm_title)) },
            text = { Text(stringResource(R.string.delete_confirm_message)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteNote(target.id)
                        notePendingDelete = null
                    },
                ) {
                    Text(
                        text = stringResource(R.string.confirm_delete),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { notePendingDelete = null }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }
}

@Composable
private fun MastheadHeader(
    totalNotes: Int,
    isDarkAppTheme: Boolean,
    onToggleDarkTheme: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                text = "Tinta Sastra",
                fontFamily = PlayfairDisplayFontFamily,
                fontSize = 28.sp,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                text = if (totalNotes == 0) {
                    "Ruang tenang untuk puisi & prosa"
                } else {
                    "$totalNotes naskah tersimpan luring"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        IconButton(
            onClick = onToggleDarkTheme,
            modifier = Modifier
                .size(48.dp)
                .testTag("toggle_app_theme"),
        ) {
            Icon(
                imageVector = if (isDarkAppTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                contentDescription = if (isDarkAppTheme) "Aktifkan mode kertas terang" else "Aktifkan mode tinta malam",
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun LibraryTabContent(
    uiState: LibraryUiState,
    isWideScreen: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onSelectMood: (MoodCategory?) -> Unit,
    onTogglePinnedFilter: () -> Unit,
    onOpenNote: (Long) -> Unit,
    onTogglePin: (PoemNoteEntity) -> Unit,
    onRequestDelete: (PoemNoteEntity) -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Search Field
        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = {
                Text(
                    text = stringResource(R.string.search_placeholder),
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null)
            },
            trailingIcon = {
                AnimatedVisibility(visible = uiState.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Hapus pencarian")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .testTag("search_notes_input"),
        )

        // Mood Category Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = uiState.selectedMood == null && !uiState.onlyPinned,
                onClick = {
                    onSelectMood(null)
                    if (uiState.onlyPinned) onTogglePinnedFilter()
                },
                label = { Text("Semua") },
                modifier = Modifier.testTag("filter_all"),
            )

            FilterChip(
                selected = uiState.onlyPinned,
                onClick = onTogglePinnedFilter,
                leadingIcon = {
                    Icon(
                        imageVector = if (uiState.onlyPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                    )
                },
                label = { Text("Disematkan") },
                modifier = Modifier.testTag("filter_pinned"),
            )

            MoodCategory.entries.forEach { mood ->
                val selected = uiState.selectedMood == mood
                FilterChip(
                    selected = selected,
                    onClick = {
                        onSelectMood(if (selected) null else mood)
                    },
                    label = { Text(mood.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(mood.tintHex),
                        selectedLabelColor = Color(mood.accentHex),
                    ),
                    modifier = Modifier.testTag("filter_mood_${mood.name.lowercase()}"),
                )
            }
        }

        if (uiState.filteredNotes.isEmpty()) {
            EmptyStateBlock(
                title = stringResource(R.string.empty_library_title),
                subtitle = if (uiState.searchQuery.isNotBlank() || uiState.selectedMood != null) {
                    "Tidak ada karya yang cocok dengan pencarian atau filter suasana."
                } else {
                    stringResource(R.string.empty_library_subtitle)
                },
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (isWideScreen) 2 else 1),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(uiState.filteredNotes, key = { it.id }) { note ->
                    LiteraryNoteCard(
                        note = note,
                        onClick = { onOpenNote(note.id) },
                        onTogglePin = { onTogglePin(note) },
                        onDelete = { onRequestDelete(note) },
                    )
                }
            }
        }
    }
}

@Composable
private fun FavoritesTabContent(
    pinnedNotes: List<PoemNoteEntity>,
    isWideScreen: Boolean,
    onOpenNote: (Long) -> Unit,
    onTogglePin: (PoemNoteEntity) -> Unit,
    onRequestDelete: (PoemNoteEntity) -> Unit,
) {
    if (pinnedNotes.isEmpty()) {
        EmptyStateBlock(
            title = stringResource(R.string.empty_favorites_title),
            subtitle = stringResource(R.string.empty_favorites_subtitle),
        )
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(if (isWideScreen) 2 else 1),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(pinnedNotes, key = { it.id }) { note ->
                LiteraryNoteCard(
                    note = note,
                    onClick = { onOpenNote(note.id) },
                    onTogglePin = { onTogglePin(note) },
                    onDelete = { onRequestDelete(note) },
                )
            }
        }
    }
}

@Composable
private fun LiteraryNoteCard(
    note: PoemNoteEntity,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit,
) {
    val metrics = remember(note.title, note.content) {
        computeWritingMetrics(note.title, note.content)
    }
    val inkColor = Color(note.colorMode.resolveHex(note.bgStyle))
    val mutedInk = inkColor.copy(alpha = 0.72f)
    val mood = note.mood

    Surface(
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("note_card_${note.id}")
            .clickable(onClick = onClick),
    ) {
        LiteraryCanvasBackground(
            style = note.bgStyle,
            customImagePath = note.customImagePath,
            blurRadius = note.backgroundBlur,
            overlayOpacity = note.overlayOpacity,
            previewMaxDim = 420,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(mood.tintHex).copy(alpha = 0.92f),
                    ) {
                        Text(
                            text = mood.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(mood.accentHex),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onTogglePin,
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("pin_note_${note.id}"),
                        ) {
                            Icon(
                                imageVector = if (note.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                contentDescription = if (note.isPinned) "Lepas sematan" else "Sematkan karya",
                                tint = if (note.isPinned) Color(0xFFD68D3B) else mutedInk,
                                modifier = Modifier.size(19.dp),
                            )
                        }
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("delete_note_${note.id}"),
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Hapus karya",
                                tint = mutedInk,
                                modifier = Modifier.size(19.dp),
                            )
                        }
                    }
                }

                Text(
                    text = note.title.ifBlank { "Tanpa Judul" },
                    fontFamily = note.font.toComposeFontFamily(),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = inkColor,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )

                Text(
                    text = note.content.ifBlank { "Belum ada bait yang ditulis…" },
                    fontFamily = note.font.toComposeFontFamily(),
                    fontSize = 14.sp,
                    lineHeight = 21.sp,
                    fontStyle = if (note.isItalic) FontStyle.Italic else FontStyle.Normal,
                    color = inkColor.copy(alpha = 0.88f),
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = buildString {
                            if (note.penName.isNotBlank()) {
                                append(note.penName)
                                append(" • ")
                            }
                            append(formatIndonesianShortDate(note.updatedAt))
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = mutedInk,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        text = "${metrics.words} kata",
                        style = MaterialTheme.typography.labelSmall,
                        color = mutedInk,
                    )
                }
            }
        }
    }
}

@Composable
private fun StudioPresetsTabContent(
    defaultPenName: String,
    isDarkAppTheme: Boolean,
    onUpdateDefaultPenName: (String) -> Unit,
    onToggleAppTheme: (Boolean) -> Unit,
    onCreateFromPreset: (StudioTemplatePreset) -> Unit,
) {
    var penDraft by remember(defaultPenName) { mutableStateOf(defaultPenName) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .navigationBarsPadding()
            .padding(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // Author identity & theme card
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp),
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = "Identitas Penulis & Tampilan",
                    style = MaterialTheme.typography.titleMedium,
                )
                OutlinedTextField(
                    value = penDraft,
                    onValueChange = {
                        penDraft = it
                        onUpdateDefaultPenName(it)
                    },
                    label = { Text("Nama Pena Bawaan") },
                    placeholder = { Text("Misal: Aksara Senja") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Mode Tinta Malam",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                        )
                        Text(
                            text = "Tampilan gelap nyaman untuk menulis malam hari",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = isDarkAppTheme,
                        onCheckedChange = onToggleAppTheme,
                    )
                }
            }
        }

        Text(
            text = "Templat Kanvas Siap Pakai",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            text = "Ketuk salah satu gaya di bawah untuk langsung menulis dengan paduan font dan latar pilihan.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        curatedStudioPresets.forEach { preset ->
            Surface(
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("preset_${preset.id}")
                    .clickable { onCreateFromPreset(preset) },
            ) {
                LiteraryCanvasBackground(
                    style = preset.background,
                    customImagePath = null,
                    blurRadius = 0f,
                    overlayOpacity = preset.overlayOpacity,
                    previewMaxDim = 420,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    val inkColor = if (preset.background.defaultDarkText) {
                        Color(0xFF251E19)
                    } else {
                        Color(0xFFFAF6EE)
                    }
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = preset.title,
                                fontFamily = preset.font.toComposeFontFamily(),
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold,
                                color = inkColor,
                            )
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color(preset.mood.tintHex),
                            ) {
                                Text(
                                    text = preset.mood.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(preset.mood.accentHex),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                )
                            }
                        }
                        Text(
                            text = preset.sampleExcerpt,
                            fontFamily = preset.font.toComposeFontFamily(),
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                            fontStyle = if (preset.isItalic) FontStyle.Italic else FontStyle.Normal,
                            color = inkColor.copy(alpha = 0.88f),
                        )
                        Text(
                            text = preset.subtitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = inkColor.copy(alpha = 0.7f),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyStateBlock(
    title: String,
    subtitle: String,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(64.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.MenuBook,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(30.dp),
                    )
                }
            }
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}
