package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.BackgroundStyle
import com.example.model.LiteraryFont
import com.example.model.MoodCategory
import com.example.model.TextAlignOption
import com.example.model.TextColorMode

@Entity(tableName = "poem_notes")
data class PoemNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String = "",
    val content: String = "",
    val penName: String = "",
    val moodCategory: String = MoodCategory.BEBAS.name,
    val isPinned: Boolean = false,
    val fontName: String = LiteraryFont.LORA.name,
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val isUnderline: Boolean = false,
    val textAlign: String = TextAlignOption.LEFT.name,
    val fontSizeSp: Float = 18f,
    val lineHeightMultiplier: Float = 1.55f,
    val letterSpacingEm: Float = 0.01f,
    val backgroundStyle: String = BackgroundStyle.WARM_PAPER.name,
    val customImagePath: String? = null,
    val backgroundBlur: Float = 0f,
    val overlayOpacity: Float = 0f,
    val textColorMode: String = TextColorMode.AUTO.name,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
) {
    val mood: MoodCategory get() = MoodCategory.fromName(moodCategory)
    val font: LiteraryFont get() = LiteraryFont.fromName(fontName)
    val align: TextAlignOption get() = TextAlignOption.fromName(textAlign)
    val bgStyle: BackgroundStyle get() = BackgroundStyle.fromName(backgroundStyle)
    val colorMode: TextColorMode get() = TextColorMode.fromName(textColorMode)
}
