package com.example

import android.app.Application
import com.example.data.PoemRepository
import com.example.data.TintaSastraDatabase

class TintaSastraApplication : Application() {
    val database: TintaSastraDatabase by lazy {
        TintaSastraDatabase.getInstance(this)
    }

    val repository: PoemRepository by lazy {
        PoemRepository(
            context = applicationContext,
            dao = database.poemNoteDao(),
        )
    }
}
