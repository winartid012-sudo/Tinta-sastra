package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PoemNoteEntity
import com.example.model.BackgroundStyle
import com.example.model.ExportRatio
import com.example.model.LiteraryFont
import com.example.model.computeWritingMetrics
import com.example.util.CardExporter
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Tinta Sastra", appName)
    }

    @Test
    fun `writing metrics count words lines and stanzas accurately`() {
        val metrics = computeWritingMetrics(
            title = "Senja",
            body = "Langit jingga perlahan redup\nMenyimpan rindu yang tetap hidup\n\nDi batas malam aku menunggu",
        )
        assertEquals(15, metrics.words)
        assertEquals(3, metrics.lines)
        assertEquals(2, metrics.stanzas)
        assertTrue(metrics.readMinutes >= 1)
    }

    @Test
    fun `card exporter renders requested social aspect ratios`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val note = PoemNoteEntity(
            title = "Puisi Uji",
            content = "Bait pertama yang tenang.\n\nBait kedua yang hangat.",
            penName = "Penulis",
            fontName = LiteraryFont.LORA.name,
            backgroundStyle = BackgroundStyle.WARM_PAPER.name,
        )

        val square = CardExporter.renderLiteraryCardBitmap(context, note, ExportRatio.SQUARE, true)
        assertEquals(1080, square.width)
        assertEquals(1080, square.height)

        val portrait = CardExporter.renderLiteraryCardBitmap(context, note, ExportRatio.PORTRAIT, true)
        assertEquals(1080, portrait.width)
        assertEquals(1350, portrait.height)

        val story = CardExporter.renderLiteraryCardBitmap(context, note, ExportRatio.STORY, false)
        assertEquals(1080, story.width)
        assertEquals(1920, story.height)
    }
}
