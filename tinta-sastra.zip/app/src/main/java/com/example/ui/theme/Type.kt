package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.LiteraryFont

val PlayfairDisplayFontFamily = FontFamily(Font(R.font.playfair_display, FontWeight.Normal))
val LoraFontFamily = FontFamily(Font(R.font.lora, FontWeight.Normal))
val MerriweatherFontFamily = FontFamily(Font(R.font.merriweather, FontWeight.Normal))
val CourierPrimeFontFamily = FontFamily(Font(R.font.courier_prime, FontWeight.Normal))
val SpecialEliteFontFamily = FontFamily(Font(R.font.special_elite, FontWeight.Normal))
val DancingScriptFontFamily = FontFamily(Font(R.font.dancing_script, FontWeight.Normal))
val GreatVibesFontFamily = FontFamily(Font(R.font.great_vibes, FontWeight.Normal))
val CaveatFontFamily = FontFamily(Font(R.font.caveat, FontWeight.Normal))
val PlusJakartaSansFontFamily = FontFamily(Font(R.font.plus_jakarta_sans, FontWeight.Normal))

fun LiteraryFont.toComposeFontFamily(): FontFamily = when (this) {
    LiteraryFont.PLAYFAIR_DISPLAY -> PlayfairDisplayFontFamily
    LiteraryFont.LORA -> LoraFontFamily
    LiteraryFont.MERRIWEATHER -> MerriweatherFontFamily
    LiteraryFont.COURIER_PRIME -> CourierPrimeFontFamily
    LiteraryFont.SPECIAL_ELITE -> SpecialEliteFontFamily
    LiteraryFont.DANCING_SCRIPT -> DancingScriptFontFamily
    LiteraryFont.GREAT_VIBES -> GreatVibesFontFamily
    LiteraryFont.CAVEAT -> CaveatFontFamily
    LiteraryFont.PLUS_JAKARTA_SANS -> PlusJakartaSansFontFamily
}

val AppTypography = Typography(
    displaySmall = TextStyle(
        fontFamily = PlayfairDisplayFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 30.sp,
        lineHeight = 38.sp,
        letterSpacing = (-0.3).sp,
    ),
    headlineMedium = TextStyle(
        fontFamily = PlayfairDisplayFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 24.sp,
        lineHeight = 32.sp,
    ),
    headlineSmall = TextStyle(
        fontFamily = LoraFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 20.sp,
        lineHeight = 28.sp,
    ),
    titleLarge = TextStyle(
        fontFamily = LoraFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 19.sp,
        lineHeight = 26.sp,
    ),
    titleMedium = TextStyle(
        fontFamily = PlusJakartaSansFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp,
    ),
    titleSmall = TextStyle(
        fontFamily = PlusJakartaSansFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
    ),
    bodyLarge = TextStyle(
        fontFamily = PlusJakartaSansFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = PlusJakartaSansFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
    ),
    bodySmall = TextStyle(
        fontFamily = PlusJakartaSansFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
    ),
    labelLarge = TextStyle(
        fontFamily = PlusJakartaSansFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
    ),
    labelMedium = TextStyle(
        fontFamily = PlusJakartaSansFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
    ),
    labelSmall = TextStyle(
        fontFamily = PlusJakartaSansFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp,
    ),
)
