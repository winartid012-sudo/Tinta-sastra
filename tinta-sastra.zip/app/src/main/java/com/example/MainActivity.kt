package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.theme.TintaSastraTheme
import com.example.viewmodel.EditorViewModel
import com.example.viewmodel.EditorViewModelFactory
import com.example.viewmodel.LibraryViewModel
import com.example.viewmodel.LibraryViewModelFactory

private const val ROUTE_LIBRARY = "library"
private const val ROUTE_EDITOR = "editor/{noteId}"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val app = LocalContext.current.applicationContext as TintaSastraApplication
            val libraryViewModel: LibraryViewModel = viewModel(
                factory = LibraryViewModelFactory(app.repository),
            )
            val libraryState by libraryViewModel.uiState.collectAsStateWithLifecycle()

            TintaSastraTheme(darkTheme = libraryState.isDarkAppTheme) {
                val navController = rememberNavController()
                NavHost(
                    navController = navController,
                    startDestination = ROUTE_LIBRARY,
                    enterTransition = { fadeIn() },
                    exitTransition = { fadeOut() },
                ) {
                    composable(ROUTE_LIBRARY) {
                        LibraryScreen(
                            uiState = libraryState,
                            onSearchQueryChange = libraryViewModel::onSearchQueryChange,
                            onSelectMood = libraryViewModel::onSelectMood,
                            onTogglePinnedFilter = libraryViewModel::onTogglePinnedFilter,
                            onOpenNote = { noteId ->
                                navController.navigate("editor/$noteId")
                            },
                            onCreateBlankNote = {
                                libraryViewModel.createNewNote { createdId ->
                                    navController.navigate("editor/$createdId")
                                }
                            },
                            onCreateFromPreset = { preset ->
                                libraryViewModel.createNoteFromPreset(preset) { createdId ->
                                    navController.navigate("editor/$createdId")
                                }
                            },
                            onTogglePin = libraryViewModel::togglePin,
                            onDeleteNote = libraryViewModel::deleteNote,
                            onUpdateDefaultPenName = libraryViewModel::updateDefaultPenName,
                            onToggleAppTheme = libraryViewModel::setDarkAppTheme,
                        )
                    }

                    composable(
                        route = ROUTE_EDITOR,
                        arguments = listOf(navArgument("noteId") { type = NavType.LongType }),
                    ) { backStackEntry ->
                        val noteId = backStackEntry.arguments?.getLong("noteId") ?: -1L
                        val editorViewModel: EditorViewModel = viewModel(
                            key = "editor_$noteId",
                            factory = EditorViewModelFactory(noteId, app.repository),
                        )
                        val editorState by editorViewModel.uiState.collectAsStateWithLifecycle()

                        EditorScreen(
                            uiState = editorState,
                            viewModel = editorViewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            },
                        )
                    }
                }
            }
        }
    }
}
