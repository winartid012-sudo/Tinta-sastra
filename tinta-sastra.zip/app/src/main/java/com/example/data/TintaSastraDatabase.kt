package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [PoemNoteEntity::class], version = 1, exportSchema = false)
abstract class TintaSastraDatabase : RoomDatabase() {
    abstract fun poemNoteDao(): PoemNoteDao

    companion object {
        @Volatile
        private var INSTANCE: TintaSastraDatabase? = null

        fun getInstance(context: Context): TintaSastraDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TintaSastraDatabase::class.java,
                    "tinta_sastra.db",
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
