package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import com.example.model.BackgroundStyle
import com.example.util.fastStackBlur
import com.example.util.loadSampledBackgroundBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.random.Random

@Composable
fun LiteraryCanvasBackground(
    style: BackgroundStyle,
    customImagePath: String?,
    blurRadius: Float,
    overlayOpacity: Float,
    modifier: Modifier = Modifier,
    previewMaxDim: Int = 900,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val context = LocalContext.current
    val quantizedBlur = blurRadius.toInt().coerceIn(0, 25)

    val processedBitmap by produceState<Bitmap?>(
        initialValue = null,
        key1 = style,
        key2 = customImagePath,
        key3 = quantizedBlur,
    ) {
        value = if (!style.isPhoto) {
            null
        } else {
            withContext(Dispatchers.Default) {
                val base = loadSampledBackgroundBitmap(
                    context = context,
                    style = style,
                    customImagePath = customImagePath,
                    maxDimensionPx = if (quantizedBlur > 0) 480 else previewMaxDim,
                ) ?: return@withContext null

                if (quantizedBlur > 0) {
                    fastStackBlur(base, quantizedBlur)
                } else {
                    base
                }
            }
        }
    }

    Box(
        modifier = modifier.background(Color(style.baseColorHex)),
    ) {
        if (style.isPhoto) {
            processedBitmap?.let { bmp ->
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            if (overlayOpacity > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0C0A09).copy(alpha = overlayOpacity.coerceIn(0f, 0.85f))),
                )
            }
        } else {
            PaperGrainOverlay(
                style = style,
                modifier = Modifier.fillMaxSize(),
            )
        }
        content()
    }
}

@Composable
private fun PaperGrainOverlay(
    style: BackgroundStyle,
    modifier: Modifier = Modifier,
) {
    if (style == BackgroundStyle.CLEAN_WHITE) return

    Canvas(modifier = modifier) {
        val vignetteColor = when (style) {
            BackgroundStyle.WARM_PAPER -> Color(0x1896764C)
            BackgroundStyle.VINTAGE_AGED -> Color(0x30805628)
            BackgroundStyle.MIDNIGHT_INK -> Color(0x45040508)
            else -> Color.Transparent
        }
        if (vignetteColor != Color.Transparent) {
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, vignetteColor),
                    center = Offset(size.width / 2f, size.height / 2f),
                    radius = maxOf(size.width, size.height) * 0.72f,
                ),
            )
        }

        val rng = Random(style.ordinal * 733 + 17)
        val dotColor = if (style == BackgroundStyle.MIDNIGHT_INK) {
            Color.White.copy(alpha = 0.045f)
        } else {
            Color(0xFF5A4228).copy(alpha = 0.04f)
        }
        repeat(220) {
            val x = rng.nextFloat() * size.width
            val y = rng.nextFloat() * size.height
            val r = (0.6f + rng.nextFloat() * 1.1f) * density
            drawCircle(color = dotColor, radius = r, center = Offset(x, y))
        }
    }
}
