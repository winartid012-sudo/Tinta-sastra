package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import com.example.model.BackgroundStyle
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

fun loadSampledBackgroundBitmap(
    context: Context,
    style: BackgroundStyle,
    customImagePath: String?,
    maxDimensionPx: Int = 1280,
): Bitmap? {
    return runCatching {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        when {
            style == BackgroundStyle.CUSTOM_IMAGE && !customImagePath.isNullOrBlank() -> {
                val file = File(customImagePath)
                if (!file.exists()) return null
                BitmapFactory.decodeFile(customImagePath, options)
                options.inSampleSize = calculateInSampleSize(options, maxDimensionPx, maxDimensionPx)
                options.inJustDecodeBounds = false
                BitmapFactory.decodeFile(customImagePath, options)
            }

            style.drawableRes != null -> {
                BitmapFactory.decodeResource(context.resources, style.drawableRes, options)
                options.inSampleSize = calculateInSampleSize(options, maxDimensionPx, maxDimensionPx)
                options.inJustDecodeBounds = false
                BitmapFactory.decodeResource(context.resources, style.drawableRes, options)
            }

            else -> null
        }
    }.getOrNull()
}

private fun calculateInSampleSize(
    options: BitmapFactory.Options,
    reqWidth: Int,
    reqHeight: Int,
): Int {
    val height = options.outHeight
    val width = options.outWidth
    var inSampleSize = 1
    if (height > reqHeight || width > reqWidth) {
        val halfHeight = height / 2
        val halfWidth = width / 2
        while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
            inSampleSize *= 2
        }
    }
    return inSampleSize.coerceAtLeast(1)
}

fun centerCropBitmap(source: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
    val result = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(result)
    val srcRatio = source.width.toFloat() / source.height.toFloat()
    val dstRatio = targetWidth.toFloat() / targetHeight.toFloat()

    val srcRect: Rect = if (srcRatio > dstRatio) {
        val croppedWidth = (source.height * dstRatio).toInt().coerceAtMost(source.width)
        val left = (source.width - croppedWidth) / 2
        Rect(left, 0, left + croppedWidth, source.height)
    } else {
        val croppedHeight = (source.width / dstRatio).toInt().coerceAtMost(source.height)
        val top = (source.height - croppedHeight) / 2
        Rect(0, top, source.width, top + croppedHeight)
    }

    val dstRect = Rect(0, 0, targetWidth, targetHeight)
    canvas.drawBitmap(source, srcRect, dstRect, null)
    return result
}

fun fastStackBlur(source: Bitmap, radiusInput: Int): Bitmap {
    val radius = radiusInput.coerceIn(0, 25)
    if (radius <= 0) return source

    val bitmap = source.copy(Bitmap.Config.ARGB_8888, true)
    val w = bitmap.width
    val h = bitmap.height
    if (w < 2 || h < 2) return bitmap

    val pix = IntArray(w * h)
    bitmap.getPixels(pix, 0, w, 0, 0, w, h)

    val wm = w - 1
    val hm = h - 1
    val wh = w * h
    val div = radius + radius + 1

    val r = IntArray(wh)
    val g = IntArray(wh)
    val b = IntArray(wh)
    val vmin = IntArray(max(w, h))

    var divsum = (div + 1) shr 1
    divsum *= divsum
    val dv = IntArray(256 * divsum)
    for (i in dv.indices) {
        dv[i] = i / divsum
    }

    var yw = 0
    var yi = 0

    val stack = Array(div) { IntArray(3) }
    val r1 = radius + 1

    for (y in 0 until h) {
        var rinsum = 0
        var ginsum = 0
        var binsum = 0
        var routsum = 0
        var goutsum = 0
        var boutsum = 0
        var rsum = 0
        var gsum = 0
        var bsum = 0

        for (i in -radius..radius) {
            val p = pix[yi + min(wm, max(i, 0))]
            val sir = stack[i + radius]
            sir[0] = (p and 0xff0000) shr 16
            sir[1] = (p and 0x00ff00) shr 8
            sir[2] = p and 0x0000ff
            val rbs = r1 - abs(i)
            rsum += sir[0] * rbs
            gsum += sir[1] * rbs
            bsum += sir[2] * rbs
            if (i > 0) {
                rinsum += sir[0]
                ginsum += sir[1]
                binsum += sir[2]
            } else {
                routsum += sir[0]
                goutsum += sir[1]
                boutsum += sir[2]
            }
        }
        var stackpointer = radius

        for (x in 0 until w) {
            r[yi] = dv[rsum]
            g[yi] = dv[gsum]
            b[yi] = dv[bsum]

            rsum -= routsum
            gsum -= goutsum
            bsum -= boutsum

            val stackstart = stackpointer - radius + div
            var sir = stack[stackstart % div]

            routsum -= sir[0]
            goutsum -= sir[1]
            boutsum -= sir[2]

            if (y == 0) {
                vmin[x] = min(x + radius + 1, wm)
            }
            val p = pix[yw + vmin[x]]

            sir[0] = (p and 0xff0000) shr 16
            sir[1] = (p and 0x00ff00) shr 8
            sir[2] = p and 0x0000ff

            rinsum += sir[0]
            ginsum += sir[1]
            binsum += sir[2]

            rsum += rinsum
            gsum += ginsum
            bsum += binsum

            stackpointer = (stackpointer + 1) % div
            sir = stack[stackpointer % div]

            routsum += sir[0]
            goutsum += sir[1]
            boutsum += sir[2]

            rinsum -= sir[0]
            ginsum -= sir[1]
            binsum -= sir[2]

            yi++
        }
        yw += w
    }

    for (x in 0 until w) {
        var rinsum = 0
        var ginsum = 0
        var binsum = 0
        var routsum = 0
        var goutsum = 0
        var boutsum = 0
        var rsum = 0
        var gsum = 0
        var bsum = 0
        var yp = -radius * w

        for (i in -radius..radius) {
            yi = max(0, yp) + x
            val sir = stack[i + radius]
            sir[0] = r[yi]
            sir[1] = g[yi]
            sir[2] = b[yi]

            val rbs = r1 - abs(i)
            rsum += r[yi] * rbs
            gsum += g[yi] * rbs
            bsum += b[yi] * rbs

            if (i > 0) {
                rinsum += sir[0]
                ginsum += sir[1]
                binsum += sir[2]
            } else {
                routsum += sir[0]
                goutsum += sir[1]
                boutsum += sir[2]
            }

            if (i < hm) {
                yp += w
            }
        }
        yi = x
        var stackpointer = radius

        for (y in 0 until h) {
            pix[yi] = (-0x1000000 and pix[yi]) or (dv[rsum] shl 16) or (dv[gsum] shl 8) or dv[bsum]

            rsum -= routsum
            gsum -= goutsum
            bsum -= boutsum

            val stackstart = stackpointer - radius + div
            var sir = stack[stackstart % div]

            routsum -= sir[0]
            goutsum -= sir[1]
            boutsum -= sir[2]

            if (x == 0) {
                vmin[y] = min(y + r1, hm) * w
            }
            val p = x + vmin[y]

            sir[0] = r[p]
            sir[1] = g[p]
            sir[2] = b[p]

            rinsum += sir[0]
            ginsum += sir[1]
            binsum += sir[2]

            rsum += rinsum
            gsum += ginsum
            bsum += binsum

            stackpointer = (stackpointer + 1) % div
            sir = stack[stackpointer]

            routsum += sir[0]
            goutsum += sir[1]
            boutsum += sir[2]

            rinsum -= sir[0]
            ginsum -= sir[1]
            binsum -= sir[2]

            yi += w
        }
    }

    bitmap.setPixels(pix, 0, w, 0, 0, w, h)
    return bitmap
}
