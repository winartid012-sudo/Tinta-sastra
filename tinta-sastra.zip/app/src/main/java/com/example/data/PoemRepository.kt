package com.example.data

import android.content.Context
import android.net.Uri
import com.example.model.BackgroundStyle
import com.example.model.LiteraryFont
import com.example.model.MoodCategory
import com.example.model.TextAlignOption
import com.example.model.TextColorMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class PoemRepository(
    private val context: Context,
    private val dao: PoemNoteDao,
) {
    private val prefs by lazy {
        context.getSharedPreferences("tinta_sastra_prefs", Context.MODE_PRIVATE)
    }

    val allNotes: Flow<List<PoemNoteEntity>> = dao.observeAllNotes()
    val pinnedNotes: Flow<List<PoemNoteEntity>> = dao.observePinnedNotes()

    fun observeNote(id: Long): Flow<PoemNoteEntity?> = dao.observeNoteById(id)

    suspend fun getNoteById(id: Long): PoemNoteEntity? = dao.getNoteById(id)

    suspend fun createNote(initial: PoemNoteEntity = PoemNoteEntity(penName = getDefaultPenName())): Long {
        val now = System.currentTimeMillis()
        return dao.insertNote(initial.copy(createdAt = now, updatedAt = now))
    }

    suspend fun saveNote(note: PoemNoteEntity) {
        dao.updateNote(note.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun togglePin(id: Long, currentPinned: Boolean) {
        dao.setPinned(id = id, pinned = !currentPinned)
    }

    suspend fun deleteNote(id: Long) {
        val existing = dao.getNoteById(id)
        dao.deleteNoteById(id)
        existing?.customImagePath?.let { path ->
            withContext(Dispatchers.IO) {
                runCatching { File(path).delete() }
            }
        }
    }

    fun getDefaultPenName(): String = prefs.getString("default_pen_name", "") ?: ""

    fun setDefaultPenName(name: String) {
        prefs.edit().putString("default_pen_name", name.trim()).apply()
    }

    fun isDarkAppTheme(): Boolean = prefs.getBoolean("dark_app_theme", false)

    fun setDarkAppTheme(enabled: Boolean) {
        prefs.edit().putBoolean("dark_app_theme", enabled).apply()
    }

    suspend fun copyPickedImageToInternalStorage(uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "backgrounds").apply { mkdirs() }
            val destFile = File(dir, "bg_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext null
            destFile.absolutePath
        }.getOrNull()
    }

    suspend fun seedStarterPoemsIfFirstLaunch() {
        if (prefs.getBoolean("has_seeded_starter_poems", false)) return
        withContext(Dispatchers.IO) {
            if (dao.countNotes() == 0) {
                val now = System.currentTimeMillis()
                val starters = listOf(
                    PoemNoteEntity(
                        title = "Sajak untuk Senja yang Pulang",
                        content = "Di ufuk jingga kita pernah berjanji,\nmenyimpan rindu di antara lembar hari.\nMeski waktu melangkah tanpa menoleh,\nnama yang kau bisikkan tetap utuh di sini.\n\nLangit meredup, angin membawa pesan,\nbahwa jarak hanyalah jeda sebelum pertemuan.",
                        penName = "Aksara Senja",
                        moodCategory = MoodCategory.RINDU.name,
                        isPinned = true,
                        fontName = LiteraryFont.PLAYFAIR_DISPLAY.name,
                        isItalic = true,
                        textAlign = TextAlignOption.CENTER.name,
                        fontSizeSp = 19f,
                        lineHeightMultiplier = 1.65f,
                        letterSpacingEm = 0.02f,
                        backgroundStyle = BackgroundStyle.IMG_SENJA.name,
                        overlayOpacity = 0.36f,
                        textColorMode = TextColorMode.WARM_IVORY.name,
                        createdAt = now - 3600_000L * 5,
                        updatedAt = now - 3600_000L * 2,
                    ),
                    PoemNoteEntity(
                        title = "Tentang Sunyi dan Secangkir Hujan",
                        content = "Ada percakapan yang tak memerlukan suara,\ncukup rintik di kaca jendela dan detak jam tua.\nKita belajar berdamai dengan yang pergi,\nsambil merawat cahaya kecil di dalam diri.",
                        penName = "Nadia K.",
                        moodCategory = MoodCategory.MELANKOLIS.name,
                        isPinned = false,
                        fontName = LiteraryFont.LORA.name,
                        textAlign = TextAlignOption.LEFT.name,
                        fontSizeSp = 18f,
                        lineHeightMultiplier = 1.6f,
                        letterSpacingEm = 0.01f,
                        backgroundStyle = BackgroundStyle.IMG_HUJAN.name,
                        overlayOpacity = 0.44f,
                        textColorMode = TextColorMode.WARM_IVORY.name,
                        createdAt = now - 86400_000L,
                        updatedAt = now - 86400_000L,
                    ),
                    PoemNoteEntity(
                        title = "Catatan Mesin Tik: Menunggu Pagi",
                        content = "Manusia sering mencari jawaban di kejauhan,\npadahal kebijaksanaan berdiam di dalam keheningan.\nBacalah langkahmu sendiri pelan-pelan,\nseperti membaca puisi di kertas yang hampir pudar.",
                        penName = "Raka Pramana",
                        moodCategory = MoodCategory.FILOSOFI.name,
                        isPinned = true,
                        fontName = LiteraryFont.COURIER_PRIME.name,
                        textAlign = TextAlignOption.LEFT.name,
                        fontSizeSp = 17f,
                        lineHeightMultiplier = 1.55f,
                        letterSpacingEm = 0.02f,
                        backgroundStyle = BackgroundStyle.VINTAGE_AGED.name,
                        overlayOpacity = 0f,
                        textColorMode = TextColorMode.DARK_INK.name,
                        createdAt = now - 172800_000L,
                        updatedAt = now - 172800_000L,
                    ),
                )
                dao.insertAll(starters)
            }
            prefs.edit().putBoolean("has_seeded_starter_poems", true).apply()
        }
    }
}
